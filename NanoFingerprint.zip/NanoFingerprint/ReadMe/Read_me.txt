This code generates a NanoFingerprint as described in:
 Francesc Serratosa, Susana Álvarez, Laura Escorihuela and Monica Calatayud, Subgraph NanoFingerprint for modelling metal oxide nanoparticles based on connected atoms exploration. NanoWeek & NanoCommons Final Conference, Cyprus 2022
Any comments are wellcome: Francesc.serratosa@urv.cat

Compile:
gcc NanoFingerprint_main.c -o NanoFingerprint_main

Parameters:
1. Graph (xyz).
2. Thickness (nm).
3. Maximum number of bonds considered per atom.

Example:
NanoFingerprint_main Al2O3_013.xyz 0.5 5

Please Cite:
Francesc Serratosa, Susana Álvarez, Laura Escorihuela and Monica Calatayud, Subgraph NanoFingerprint for modelling metal oxide nanoparticles based on connected atoms exploration. NanoWeek & NanoCommons Final Conference, Cyprus 2022.

