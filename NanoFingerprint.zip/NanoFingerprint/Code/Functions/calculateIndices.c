void calculateIndices(int init, int index, int max_bonds, int *a, int *b, int *c, int *d){
    
    if (init == pow(max_bonds + 1, 4)){
        index = index - pow(max_bonds + 1, 4) - 1;
    }
    else if (init == 2*pow(max_bonds + 1, 4)){
        index = index - 2*pow(max_bonds + 1, 4) - 1;
    }
    
    *d = index % (max_bonds+1);
    index = index/(max_bonds+1);
    *c = index % (max_bonds+1);
    index = index/(max_bonds+1);
    *b = index % (max_bonds+1);
    index = index/(max_bonds+1);
    *a = index % (max_bonds+1);
    index = index/(max_bonds+1);
}