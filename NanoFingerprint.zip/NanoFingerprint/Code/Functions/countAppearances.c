int countAppearances(struct Graph *graph, struct localStructure *local_structure, struct localStructureList *local_structure_list, int atomic_M) 
{
    int *a;			
    int count = 0;
    int degree;

    for (int j = 0; j < numVertices(graph); j++){
        if (atomicOfNode(graph, j) == getAtomic(local_structure))
        {
            degree = degreeOfNode(graph, j);
            if (degree == (getO_connections(local_structure)+getM_connections(local_structure))){
                a = getSurroundingNodesAtomic(graph, j);
                if (countO(a, degree) == getO_connections(local_structure)){
                    count++;
                    addLocalStructure(local_structure_list,local_structure,j);
                }
                free(a);
            }
        }
    }

    return count;
}