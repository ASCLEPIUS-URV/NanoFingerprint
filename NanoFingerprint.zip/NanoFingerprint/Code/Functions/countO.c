int countO(int *atomics, int atomics_size){
    int O_appearances = 0;
    for (int i = 0; i < atomics_size; i++)
    {
        if (atomics[i]==atomic_O){
            O_appearances=O_appearances+1;
        }
    }
    return O_appearances;
}