void countOM(int *atomics, int atomics_size, int *O_appearances, int *M_appearances){
    for (int i = 0; i < atomics_size; i++){
        if (atomics[i]==atomic_O){
            *O_appearances=*O_appearances+1;
        }
        else {
            *M_appearances = *M_appearances + 1;
        }
    }
}