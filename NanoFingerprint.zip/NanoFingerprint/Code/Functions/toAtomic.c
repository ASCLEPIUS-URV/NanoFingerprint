#include <stdio.h>
#include <string.h>

int toAtomic(char element[2])
{
	int atomic;

	if (!strcmp(element,"H")) {
		atomic=1;
	} else if (!strcmp(element,"He")) {
		atomic=2;
	} else if (!strcmp(element,"Li")) {
		atomic=3;
	} else if (!strcmp(element,"Be")) {
		atomic=4;
	} else if (!strcmp(element,"B")) {
		atomic=5;
	} else if (!strcmp(element,"C")) {
		atomic=6;
	} else if (!strcmp(element,"N")) {
		atomic=7;
	} else if (!strcmp(element,"O")) {
		atomic=8;
	} else if (!strcmp(element,"F")) {
		atomic=9;
	} else if (!strcmp(element,"Ne")) {
		atomic=10;
	} else if (!strcmp(element,"Na")) {
		atomic=11;
	} else if (!strcmp(element,"Mg")) {
		atomic=12;
	} else if (!strcmp(element,"Al")) {
		atomic=13;
	} else if (!strcmp(element,"Si")) {
		atomic=14;
	} else if (!strcmp(element,"P")) {
		atomic=15;
	} else if (!strcmp(element,"S")) {
		atomic=16;
	} else if (!strcmp(element,"Cl")) {
		atomic=17;
	} else if (!strcmp(element,"Ar")) {
		atomic=18;
	} else if (!strcmp(element,"K")) {
		atomic=19;
	} else if (!strcmp(element,"Ca")) {
		atomic=20;
	} else if (!strcmp(element,"Sc")) {
		atomic=21;
	} else if (!strcmp(element,"Ti")) {
		atomic=22;
	} else if (!strcmp(element,"V")) {
		atomic=23;
	} else if (!strcmp(element,"Cr")) {
		atomic=24;
	} else if (!strcmp(element,"Mn")) {
		atomic=25;
	} else if (!strcmp(element,"Fe")) {
		atomic=26;
	} else if (!strcmp(element,"Co")) {
		atomic=27;
	} else if (!strcmp(element,"Ni")) {
		atomic=28;
	} else if (!strcmp(element,"Cu")) {
		atomic=29;
	} else if (!strcmp(element,"Zn")) {
		atomic=30;
	} else if (!strcmp(element,"Ga")) {
		atomic=31;
	} else if (!strcmp(element,"Ge")) {
		atomic=32;
	} else if (!strcmp(element,"As")) {
		atomic=33;
	} else if (!strcmp(element,"Se")) {
		atomic=34;
	} else if (!strcmp(element,"Br")) {
		atomic=35;
	} else if (!strcmp(element,"Kr")) {
		atomic=36;
	} else if (!strcmp(element,"Rb")) {
		atomic=37;
	} else if (!strcmp(element,"Sr")) {
		atomic=38;
	} else if (!strcmp(element,"Y")) {
		atomic=39;
	} else if (!strcmp(element,"Zr")) {
		atomic=40;
	} else if (!strcmp(element,"Nb")) {
		atomic=41;
	} else if (!strcmp(element,"Mo")) {
		atomic=42;
	} else if (!strcmp(element,"Tc")) {
		atomic=43;
	} else if (!strcmp(element,"Ru")) {
		atomic=44;
	} else if (!strcmp(element,"Rh")) {
		atomic=45;
	} else if (!strcmp(element,"Pd")) {
		atomic=46;
	} else if (!strcmp(element,"Ag")) {
		atomic=47;
	} else if (!strcmp(element,"Cd")) {
		atomic=48;
	} else if (!strcmp(element,"In")) {
		atomic=49;
	} else if (!strcmp(element,"Sn")) {
		atomic=50;
	} else if (!strcmp(element,"Sb")) {
		atomic=51;
	} else if (!strcmp(element,"Te")) {
		atomic=52;
	} else if (!strcmp(element,"I")) {
		atomic=53;
	} else if (!strcmp(element,"Xe")) {
		atomic=54;
	} else if (!strcmp(element,"Cs")) {
		atomic=55;
	} else if (!strcmp(element,"Ba")) {
		atomic=56;
	} else if (!strcmp(element,"La")) {
		atomic=57;
	} else if (!strcmp(element,"Ce")) {
		atomic=58;
	} else if (!strcmp(element,"Pr")) {
		atomic=59;
	} else if (!strcmp(element,"Nd")) {
		atomic=60;
	} else if (!strcmp(element,"Pm")) {
		atomic=61;
	} else if (!strcmp(element,"Sm")) {
		atomic=62;
	} else if (!strcmp(element,"Eu")) {
		atomic=63;
	} else if (!strcmp(element,"Gd")) {
		atomic=64;
	} else if (!strcmp(element,"Tb")) {
		atomic=65;
	} else if (!strcmp(element,"Dy")) {
		atomic=66;
	} else if (!strcmp(element,"Ho")) {
		atomic=67;
	} else if (!strcmp(element,"Er")) {
		atomic=68;
	} else if (!strcmp(element,"Tm")) {
		atomic=69;
	} else if (!strcmp(element,"Yb")) {
		atomic=70;
	} else if (!strcmp(element,"Lu")) {
		atomic=71;
	} else if (!strcmp(element,"Hf")) {
		atomic=72;
	} else if (!strcmp(element,"Ta")) {
		atomic=73;
	} else if (!strcmp(element,"W")) {
		atomic=74;
	} else if (!strcmp(element,"Re")) {
		atomic=75;
	} else if (!strcmp(element,"Os")) {
		atomic=76;
	} else if (!strcmp(element,"Ir")) {
		atomic=77;
	} else if (!strcmp(element,"Pt")) {
		atomic=78;
	} else if (!strcmp(element,"Au")) {
		atomic=79;
	} else if (!strcmp(element,"Hg")) {
		atomic=80;
	} else if (!strcmp(element,"Tl")) {
		atomic=81;
	} else if (!strcmp(element,"Pb")) {
		atomic=82;
	} else if (!strcmp(element,"Bi")) {
		atomic=83;
	} else if (!strcmp(element,"Po")) {
		atomic=84;
	} else if (!strcmp(element,"At")) {
		atomic=85;
	} else if (!strcmp(element,"Rn")) {
		atomic=86;
	} else if (!strcmp(element,"Fr")) {
		atomic=87;
	} else if (!strcmp(element,"Ra")) {
		atomic=88;
	} else if (!strcmp(element,"Ac")) {
		atomic=89;
	} else if (!strcmp(element,"Th")) {
		atomic=90;
	} else if (!strcmp(element,"Pa")) {
		atomic=91;
	} else if (!strcmp(element,"U")) {
		atomic=92;
	} else if (!strcmp(element,"Np")) {
		atomic=93;
	} else if (!strcmp(element,"Pu")) {
		atomic=94;
	} else if (!strcmp(element,"Am")) {
		atomic=95;
	} else if (!strcmp(element,"Cm")) {
		atomic=96;
	} else if (!strcmp(element,"Bk")) {
		atomic=97;
	} else if (!strcmp(element,"Cf")) {
		atomic=98;
	} else if (!strcmp(element,"Es")) {
		atomic=99;
	} else if (!strcmp(element,"Fm")) {
		atomic=100;
	} else if (!strcmp(element,"Md")) {
		atomic=101;
	} else if (!strcmp(element,"No")) {
		atomic=102;
	} else if (!strcmp(element,"Lr")) {
		atomic=103;
	} else if (!strcmp(element,"Rf")) {
		atomic=104;
	} else if (!strcmp(element,"Db")) {
		atomic=105;
	} else if (!strcmp(element,"Sg")) {
		atomic=106;
	} else if (!strcmp(element,"Bh")) {
		atomic=107;
	} else if (!strcmp(element,"Hs")) {
		atomic=108;
	} else if (!strcmp(element,"Mt")) {
		atomic=109;
	} else if (!strcmp(element,"Ds")) {
		atomic=110;
	} else if (!strcmp(element,"Rg")) {
		atomic=111;
	} else if (!strcmp(element,"Cn")) {
		atomic=112;
	} else if (!strcmp(element,"Nh")) {
		atomic=113;
	} else if (!strcmp(element,"Fl")) {
		atomic=114;
	} else if (!strcmp(element,"Mc")) {
		atomic=115;
	} else if (!strcmp(element,"Lv")) {
		atomic=116;
	} else if (!strcmp(element,"Ts")) {
		atomic=117;
	} else if (!strcmp(element,"Og")) {
		atomic=118;
	} else {
		atomic=-1;
	}
	return atomic;
}
