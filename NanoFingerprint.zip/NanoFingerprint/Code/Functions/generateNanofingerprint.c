int generateNanofingerprint (char nano_file[100], int max_bons, float *section1, int *section2, int *section3, int *section4, char verbose[4]){

    FILE *f;
    int err = 0, i = 0, pos = 1;
    char filename_out[100];
    strcpy(filename_out,nano_file);
    strcat(filename_out, verbose);
    strcat(filename_out, ".txt");

    f = fopen(filename_out, "w");

    if (f==NULL)
    {
        err=-3;
    }
    else
    {
        
        // Section 1

        if (strcmp(verbose,"NV")!=0){
            fprintf(f,"Shell: %d\n", (int)section1[i++]);
            fprintf(f,"MaxBonds: %d\n", (int)section1[i++]);
            fprintf(f,"Size: %f\n", section1[i++]);
            fprintf(f,"Atomic: %d\n", (int)section1[i++]);
            fprintf(f,"O: %d\n", (int)section1[i++]);
            fprintf(f,"M: %d\n", (int)section1[i++]);
        }
        else{
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%f\n", section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
        }

        // Section 2
        char at[2] = {'O', 'M'};
        pos = i + 1;
        i = 0;
        for (int a = 0; a < 2; a++)
        {
            for (int j = 0; j < max_bons; j++){
                if ((strcmp(verbose,"NV")!=0) && (strcmp(verbose,"VZ")==0 || section2[i] != 0)){
                    fprintf(f, "%d-> %c[%d]: %d\n", pos,at[a], j+1, section2[i]);  
                }
                else if (strcmp(verbose,"NV")==0){
                    fprintf(f, "%d\n", section2[i]);  
                }
                i++;
                pos++;
            }
        }

        // Section 3
        i = 0;
        for (int a = 0; a < 2; a++)
        {
            for (int j = 0; j <= max_bons; j++)
            {
                for (int k = 0; k <= max_bons; k++)
                {
                    if ((strcmp(verbose,"NV")!=0) && (strcmp(verbose,"VZ")==0 || section3[i] != 0)){
                        fprintf(f, "%d-> %c[%d,%d]: %d\n", pos,at[a], j, k, section3[i]);
                    }
                    else if (strcmp(verbose,"NV")==0){
                        fprintf(f, "%d\n", section3[i]);  
                    }
                    i++;
                    pos++;
                }
            }
        }
        
        // Section 4
        int a, b, c, d, init = 0;
        for (int el = 0; el <= 2; el++)
        {
            for (i = init; i <= (el+1) * pow(max_bons + 1, 4); i++)
            {
                 if ((strcmp(verbose,"NV")!=0) && (strcmp(verbose,"VZ")==0 || section4[i] != 0)){
                    calculateIndices(init,i, max_bons, &a, &b, &c, &d);
                    if (el!=2){
                        fprintf(f, "%d-> %c[%d,%d]_%c[%d,%d]: %d\n", pos, at[el],a, b, at[el],c, d, section4[i]);
                    }
                    else{
                        fprintf(f, "%d-> %c[%d,%d]_%c[%d,%d]: %d\n", pos, at[0],a, b, at[1],c, d, section4[i]);
                    }
                }
                else if (strcmp(verbose,"NV")==0){
                    fprintf(f, "%d\n", section4[i]);  
                }

                pos++;
            }

            init = (el+1) * pow(max_bons + 1, 4);
        }

        fclose(f);
    }

    return err;
}