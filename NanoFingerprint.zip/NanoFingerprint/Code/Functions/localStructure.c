// Local Structure struct
// Composed by atomic number of central element, bonds with Oxygen, bonds with Metal
struct localStructure {
  int atomic;
  int O_connections;
  int M_connections;
};

// Local Structure List struct
struct localStructureList {
  int numLocalStructures;
  int *node;
  struct localStructure **list;
};

// Create a Local Structure
struct localStructure* createLocalStructure(int atomic, int O_connections, int M_connections) {
  struct localStructure* localStructure = malloc(sizeof(struct localStructure));
  localStructure->atomic = atomic;
  localStructure->O_connections = O_connections;
  localStructure->M_connections = M_connections;
  return localStructure;
}

// Create a Local Structuure List
struct localStructureList* createLocalStructureList(int maxElements) {

  struct localStructureList* localStructureList = malloc(sizeof(struct localStructureList));
  localStructureList->numLocalStructures = 0;
  localStructureList->node = (int*)malloc(maxElements*sizeof(int));
  localStructureList->list = malloc(maxElements * sizeof(struct localStructure *));
  
  for (int i = 0; i < maxElements; i++){
    localStructureList->node[i] = 0;
    localStructureList->list[i] = NULL;
  }
  
  return localStructureList;

}

void addLocalStructure(struct localStructureList* localStructureList, struct localStructure *localStructure, int n) {

  struct localStructure *newLocalStructure = malloc(sizeof(struct localStructure));
  memcpy(newLocalStructure, localStructure, sizeof(struct localStructure));

  localStructureList->list[localStructureList->numLocalStructures] = newLocalStructure;
  localStructureList->node[localStructureList->numLocalStructures] = n;
  localStructureList->numLocalStructures++;

}

int getNumLocalStructures (struct localStructureList* localStructureList){
  return localStructureList->numLocalStructures;
}

int getNodeAtPosition(struct localStructureList* localStructureList, int position){
  return localStructureList->node[position];
}

int getAtomic(struct localStructure* localStructure){
  return localStructure->atomic;
}

int getO_connections(struct localStructure* localStructure){
  return localStructure->O_connections;
}

int getM_connections(struct localStructure* localStructure){
  return localStructure->M_connections;
}

void addElement(struct localStructureList* localStructureList, int* section4, int max_bonds, int pos_1, int pos_2){
  
  struct localStructure *localStructure_1 = malloc(sizeof(struct localStructure));
  memcpy(localStructure_1, localStructureList->list[pos_1], sizeof(struct localStructure));

  struct localStructure *localStructure_2 = malloc(sizeof(struct localStructure));
  memcpy(localStructure_2, localStructureList->list[pos_2], sizeof(struct localStructure));

  int index = localStructure_1->M_connections + pow(max_bonds+1,1) * localStructure_1->O_connections + pow(max_bonds+1,2) * localStructure_2->M_connections + pow(max_bonds+1,3) * localStructure_2->O_connections;
  
  if (getAtomic(localStructure_1)!= atomic_O && getAtomic(localStructure_2)  != atomic_O){
    index = index + pow(max_bonds+1, 4) + 1;
  } else if (localStructure_1->atomic != atomic_O){
    index = index + 2*pow(max_bonds+1, 4) + 1;
  } else if (localStructure_2->atomic != atomic_O){
    int last_digit = index % (max_bonds+1);
    int second_last_digit = (index / (max_bonds+1)) % (max_bonds+1);
    index = index / pow(max_bonds+1,2);
    index = last_digit * pow(max_bonds+1,2) + second_last_digit * pow(max_bonds+1,3) + index;
    index = index + 2*pow(max_bonds+1, 4) + 1;
  }

  section4[index]++;

  free(localStructure_1);
  free(localStructure_2);
}