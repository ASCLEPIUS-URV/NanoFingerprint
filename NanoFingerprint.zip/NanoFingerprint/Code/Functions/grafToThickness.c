#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define E 4

int graphToThickness (char graph[100], float thickness, char out[100], double *dist_max)
{
	char line[150];
	float suma_x=0,suma_y=0,suma_z=0,x,y,z,dist,a;
	int numatoms,err=0,new_atom=0;
	FILE *f,*g;

	float **positions;
	int *list;

	f=fopen(graph,"r");
	g=fopen(out,"w");
	if (f==NULL)
	{	
		err=-1;
	}
	else
	{
		if (g==NULL)
		{	
			err=-2;
		}
		else
		{
			fscanf(f,"%d\n",&numatoms);
			positions=(float **)malloc(numatoms*sizeof(float*));
			if (positions==NULL)
			{
				err=-4;
			}
			else
			{
				for (int i=0;i<numatoms;i++)
				{
					positions[i]=(float*)malloc(3*sizeof(float));
				}
				if (positions==NULL)
				{
					err=-4;
				}
				else
				{
					list=(int *)malloc(numatoms*sizeof(int));
					if (list==NULL)
					{
						err=-4;
					}
					else
					{
						memset(list, 0, numatoms*sizeof(int));
						fgets(line,20,f);
						fscanf(f,"%s",line);
						for (int i=0;!feof(f);i++)
						{
							fscanf(f,"%f",&x);
							positions[i][0]=x;
							fscanf(f,"%f",&y);
							positions[i][1]=y;
							fscanf(f,"%f\n",&z);
							positions[i][2]=z;
							fscanf(f,"%s",line);
							suma_x=suma_x+x;
							suma_y=suma_y+y;
							suma_z=suma_z+z;
						}
						suma_x=suma_x/numatoms;
						suma_y=suma_y/numatoms;
						suma_z=suma_z/numatoms;
						for (int i=0; i<numatoms;i++)
						{
							dist=calculateDistance(positions[i][0],positions[i][1],positions[i][2],suma_x,suma_y,suma_z);
							if(dist>*dist_max)
							{
								*dist_max=dist;
							}
						}
						a=*dist_max-(thickness+E);
						for (int i=0; i<numatoms;i++)
						{
							if (calculateDistance(positions[i][0],positions[i][1],positions[i][2],suma_x,suma_y,suma_z)>a)
							{
								list[i]=1;
								new_atom++;
							}
						}
						if (new_atom==0)
						{
							err=-3;
						}
						else
						{
							fprintf(g,"%d\n",new_atom);
							rewind(f);
							fscanf(f,"%d\n",&numatoms);
							fgets(line,20,f);
							line[strlen(line)-2]='\0';
							strcat(line,"_thickness");
							fprintf(g,"%s\n",line);
							for (int i=0;new_atom!=0;i++)
							{
								if (list[i]==1)
								{
									fgets(line,150,f);
									fprintf(g,"%s",line);
									new_atom--;
								}
								else
								{
									fgets(line,150,f);
								}
							}
						}
						free(list);
					}
					free(positions);
				}
			}
			fclose(g);
		}
		fclose(f);
	}
	return err;
}
