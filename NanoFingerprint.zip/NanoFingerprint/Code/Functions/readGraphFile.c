struct Graph* readGraphFile(char graph_txt[100]){

    FILE *f;
    int err = 0, node, node_s, node_d, atomic, numatoms, deg;
    struct Graph *graph;

    f=fopen(graph_txt,"r");

    if (f==NULL)
    {	
        err=-3;
    }
    else{

		  fscanf(f,"%d\n",&numatoms);
      graph = createGraph(numatoms);
      // Read node lines
      for (int i = 0; i < numatoms; i++){
		    fscanf(f,"%d %d\n",&node,&atomic);
        addAtomic(graph, node, atomic);
      }

      for (int i = 0; i < numatoms; i++){
        fscanf(f,"%d\n",&deg);
        graph->degree[i] = deg;
        for (int j = 0; j < deg; j++){
          fscanf(f,"%d %d\n",&node_s,&node_d);
          addEdge(graph, node_s, node_d);
        }
      }
    }

    return graph;
}