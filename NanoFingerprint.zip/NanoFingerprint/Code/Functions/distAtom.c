#include <stdio.h>

float distAtom(int a1, int a2)
{
	float dist_atom=2.2;
	if (a1==a2)	
	{
		switch (a1)
		{
			case 8:
				dist_atom=1.5;
				break;
			case 22:
				dist_atom=3;
				break;
			case 30:
				dist_atom=3.5;
				break;
			case 26:
				dist_atom=3.7;
				break;
			case 13:
				dist_atom=2.86;
				break;
			case 29:
				dist_atom=3.1;
				break;
		}
	}
	else
	{
		if ((a1==22 && a2==8) || (a1==8 && a2==22))
		{
			dist_atom=2.35;
		}
		else if ((a1==30 && a2==8) || (a1==8 && a2==30))
		{
			dist_atom=2.11;
		}
		else if ((a1==8 && a2==26) || (a1==26 && a2==8))
		{
			dist_atom=3.5;
		}
		else if ((a1==8 && a2==13) || (a1==13 && a2==8))
		{
			dist_atom=2.2;
		}
		else if ((a1==8 && a2==29) || (a1==29 && a2==8))
		{
			dist_atom=3.9;
		}
	}
	return dist_atom;
}
