// Node struct
struct node {
  int vertex;
  struct node *next;
};

// Graph struct
struct Graph {
  int numVertices;
  int *atomic_numbers;
  int *degree;
  struct node **adjLists;
};

// Create a node
struct node* createNode(int v) {
  struct node* newNode = malloc(sizeof(struct node));
  newNode->vertex = v;
  newNode->next = NULL;
  return newNode;
}

// Create a graph
struct Graph* createGraph(int vertices) {
  struct Graph* graph = malloc(sizeof(struct Graph));
  graph->atomic_numbers = (int*)malloc(vertices*sizeof(int));
  graph->degree = (int*)malloc(vertices*sizeof(int));
  graph->numVertices = vertices;
  graph->adjLists = malloc(vertices * sizeof(struct node*));

  for (int i = 0; i < vertices; i++){
    graph->adjLists[i] = NULL;
    graph->atomic_numbers[i] = 0;
    graph->degree[i] = 0;
  }
  
  return graph;
}

// Add edges to the graph from source (s) to destination (d)
void addEdge(struct Graph* graph, int node_s, int node_d) {
  // Add edge from s to d (graphs are directed and specify both directions)
  struct node* newNode = createNode(node_d);
  newNode->next = graph->adjLists[node_s];
  graph->adjLists[node_s] = newNode;
}

void addAtomic(struct Graph* graph, int node, int atomic){
  graph->atomic_numbers[node] = atomic;
}

// Print the graph
void printGraph(struct Graph* graph) {
  int v;
  for (v = 0; v < graph->numVertices; v++) {
    struct node *temp = graph->adjLists[v];
    printf("\nVertex %d (at=%d, deg=%d): ", v,graph->atomic_numbers[v], graph->degree[v]);
    while (temp) {
      printf("-> %d ", temp->vertex);
      temp = temp->next;
    }
  }
}

int numVertices(struct Graph* graph){
  return graph->numVertices;
}

int degreeOfNode(struct Graph* graph, int node){
  return graph->degree[node];
}

int atomicOfNode(struct Graph* graph, int node){
  return graph->atomic_numbers[node];
}

int *getAtomics(struct Graph* graph){
  return graph->atomic_numbers;
}

int *getSurroundingNodesAtomic(struct Graph* graph, int node){
  struct node *temp = graph->adjLists[node];
  int i = 0;
  int *atomics = (int*)malloc(degreeOfNode(graph,node)*sizeof(int));
  while (temp)
  {
    atomics[i++] = atomicOfNode(graph,temp->vertex);
    temp = temp->next;
  }
  return atomics;
}

int *getSurroundingNodes(struct Graph* graph, int node){
  struct node *temp = graph->adjLists[node];
  int i = 0;
  int *nodes = (int*)malloc(degreeOfNode(graph,node)*sizeof(int));
  while (temp)
  {
    nodes[i++] = temp->vertex;
    temp = temp->next;
  }
  return nodes;
}

