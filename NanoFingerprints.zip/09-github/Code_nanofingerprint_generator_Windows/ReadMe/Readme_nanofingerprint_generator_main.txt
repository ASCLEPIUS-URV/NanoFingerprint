CODI

Dins la carpeta 'Code':

El main és el programa nanofingerprint_generator_main.c

Les funcions utilizades estan a functions.c

Capçaleres de les funcions, i includes, estan a functions.h

Les estructures definides estan a struct.h

COMPILAR I CREAR EXECUTABLE en MacOS

Primer, anar a la carpeta 'Code', utilitzant la instrucció 'cd'.

Un cop allà, fer:

gcc nanofingerprint_generator_main.c functions.c -o nanofingerprint_generator_main

En aquest cas, hem anomenat el programa 'nanofingerprint_generator_main', però el podem anomenar com vulguem.

Es generarà arxiu executable a la carpeta Code.

CRIDAR PROGRAMA

Anar a la carpeta Code, utilitzant la instrucció 'cd'.

Un cop allà, fer, per exemple:

nanofingerprint_generator_main Al2O3_013.xyz 100 5

Paràmetres:
1. Graph (xyz).
2. Thickness (nm)
3. Nombre màxim d'enllaços (max_bonds).

ALTRES

Els NanoFingerprints generats aniran a parar a la carpeta 'Generated_NanoFingerprints'.

El programa també genera un fitxer 'Results.csv' (el situa a la carpeta 'Code') on hi escriu, en cada columna, el nom del fitxer (nanopartícula), el nombre d'àtoms i el temps d'execució en segons.

Les estructures XYZ s'han de col·locar a la carpeta 'Structures_xyz'.

Per realitzar múltiples generacions, cal utilitzar l'arxiu 'Run_all' situat a la carpeta 'Code'. Cal canviar-li l'extensió .txt a .bat. En cas d'anomenar l'executable diferent a nanofingerprint_generator_main, cal canviar-ho. En cas de situar els fitxers xyz en una altra carpeta, o voler situar les generacions en una altra carpeta, cal canviar-ho, també.
