#include "structs.h"
#include "functions.h"

int main(int argc, char *argv[])
{

	// Inputs
	// argv[0] - program name
	// argv[1] - folder xyz files
	// argv[2] - thickness (nm)
	// argv[3] - Maximum number of bonds per atom

	char path_results[100] = "../Generated_Nanofingerprints/";
	char path_input_files[100] = "../Structures_xyz/";
	char graph[100]= "\0", path_input_graph[100]= "\0",path_input_subgraph[100]= "\0";

	char nano_file[100] = "\0";
	char graph_thickness[100] = "\0";


	double dist_max =0, size, execution_time;
	clock_t start, end;

	int status = 0, thickness, max_bonds, numatoms_graph, atomic_M, i = 0, N = 0;
	int O_appearances = 0, M_appearances = 0, appearances = 0;

	start = clock();

	int err = 0;

	if (argc!=4)
	{
		err=-1;
	}
	else
	{

		strcpy(graph, argv[1]);

		printf("\nFile: %s\n", graph);
	
		thickness = atof(argv[2]);
		max_bonds = atof(argv[3]);
		
		strcpy(path_input_graph,path_input_files);

		strcat(nano_file,path_results);

		strcat(path_input_graph, graph); 

		printf("Complete path to file: %s\n", path_input_graph);

		strcat(nano_file,graph);
		strtok(nano_file,".");
		strcat(nano_file, "_nanofingerprint_");
		strcat(nano_file, argv[3]);
		strcat(nano_file, "_");

		strcat(graph_thickness, graph);
		strtok(graph_thickness,".");
		strcat(graph_thickness, "_thickness.xyz");

		status=graphToThickness(path_input_graph, thickness, graph_thickness, &dist_max,&numatoms_graph);
		if (status==0)
		{
			struct Graph *grf = createGraph(numatoms_graph);
			
			status = xyzToGraph(graph_thickness, &atomic_M, grf);

			if (status==0)
			{
				remove(graph_thickness);
				N = numVertices(grf);

				// Section 1
				countOM(getAtomics(grf), numVertices(grf), &O_appearances, &M_appearances);

				float *section1 = (float *)malloc(6*sizeof(float));
				section1[i++] = thickness;
				section1[i++] = max_bonds;
				size = 2 * dist_max;
				section1[i++] = size;
				section1[i++] = atomic_M;
				section1[i++] = O_appearances;
				section1[i] = M_appearances;

				int *section2 = (int *)malloc(2*max_bonds * sizeof(int));
				memset(section2, 0, 2*(max_bonds+1)*sizeof(int));
				int *section3 = (int *)malloc(2*(max_bonds+1)*(max_bonds+1) * sizeof(int));
				memset(section3, 0, 2*(max_bonds+1)*(max_bonds+1)*sizeof(int));

				i = 0;
				int at[2] = {atomic_O, atomic_M};

				struct localStructureList *local_structure_list = createLocalStructureList(2*numVertices(grf)*(max_bonds+1)*(max_bonds+1));

				int *a;			
				int count = 0;
				int degree = 0;

				// Section 2 and Section 3

				for (int j = 0; j < numVertices(grf); j++){

					degree = degreeOfNode(grf, j);
					a = getSurroundingNodesAtomic(grf, j);

					O_appearances = 0;
					M_appearances = 0;

					countOM(a, degree, &O_appearances, &M_appearances);

					if (degree <= max_bonds){
						addLocalStructure(local_structure_list,createLocalStructure(atomicOfNode(grf, j), O_appearances, M_appearances),j);
					}

					if (atomicOfNode(grf, j) == atomic_O && degree <= max_bonds){
						if (degree>0){
							section2[degree-1]++;
							
						}
						section3[(max_bonds+1)*O_appearances + M_appearances]++;
					}
					else if (degree <= max_bonds) {
						if (degree>0){
							section2[degree+max_bonds-1]++;
						}
						section3[(max_bonds+1)*(max_bonds+1)+(max_bonds+1)*O_appearances + M_appearances]++;
					}

					free(a);

				}

				int *nodes;
				
				int *section4 = (int *)malloc(3*(pow(max_bonds+1,4)) * sizeof(int));
				memset(section4, 0, 3*(pow(max_bonds+1,4))*sizeof(int));

				// Section 4
				for (int elem = 0; elem < getNumLocalStructures(local_structure_list); elem++)
				{

					degree = degreeOfNode(grf, getNodeAtPosition(local_structure_list,elem));
					nodes = getSurroundingNodes(grf, getNodeAtPosition(local_structure_list,elem));
					
					for (int j = 0; j < degree; j++){
						for (int k = elem+1; k < getNumLocalStructures(local_structure_list); k++){
								if (nodes[j] == getNodeAtPosition(local_structure_list,k)){
									addElement(local_structure_list, section4, max_bonds ,elem, k);
								}
						}
					}

					free(nodes);
				}
				
				free(local_structure_list);
				free(grf);

				status = generateNanofingerprint(nano_file, max_bonds, section1, section2, section3, section4, "VNZ");
				status = generateNanofingerprint(nano_file, max_bonds, section1, section2, section3, section4, "NV");

				free(section1);
				free(section2);
				free(section3);
				free(section4);
			}
			else
			{ 
				if (status==-1)
				{
					err=-2;
				}
				else
				{
					if (status==-2)
					{
						err=-3;
					}
				}
			}
		}
		else
		{
			if (status==-1)
			{
				err=-2;
			}
			else
			{
				if (status==-2)
				{
					err=-5;
				}
				else
				{
					err=-6;
				}
			}
		}
		
	}

	if (err != 0){
			printf("Error: %d\n",err);
	}
	else{
			char filename_out_VNZ[sizeof(nano_file)];
			strcpy(filename_out_VNZ,nano_file);
			strcat(filename_out_VNZ, "VNZ");
			strcat(filename_out_VNZ, ".txt");

			char *match = strstr(filename_out_VNZ, "../");
			memmove(match, match + strlen("../"),strlen(match+strlen("../"))+1);
			printf("Nanofingerprint VNZ file path: %s\n", filename_out_VNZ);

			char filename_out_NV[sizeof(nano_file)];
			strcpy(filename_out_NV,nano_file);
			strcat(filename_out_NV, "NV");
			strcat(filename_out_NV, ".txt");

			match = strstr(filename_out_NV, "../");
			memmove(match, match + strlen("../"),strlen(match+strlen("../"))+1);
			printf("Nanofingerprint VNZ file path: %s\n", filename_out_NV);

			end = clock();
			execution_time = ((double)(end-start))/CLOCKS_PER_SEC; 
			printf("Execution time (s): %f\n",execution_time);

			writecsv("Results.csv", graph, N, execution_time);

	}

	return err;
}