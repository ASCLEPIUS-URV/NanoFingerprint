function NMSE = calculateNMSE(y_real, y_pred)
    prod = (y_real-y_pred)./max(abs(y_pred),abs(y_real)); % Normalize by dividing by the max of each of the two substracted elements
    prod(isnan(prod)) = 0; % Setting all Nans to 0
    NMSE = prod*prod'/size(prod,2);
    NMSE = diag(NMSE); % Error of each NanoFingerprint
    NMSE = sum(NMSE)/size(NMSE,1);
end