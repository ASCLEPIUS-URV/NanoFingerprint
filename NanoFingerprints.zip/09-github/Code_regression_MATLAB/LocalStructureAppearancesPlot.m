%% PLOT OF LOCAL STRUCTURE VS SIZE

clear;
close all;

addpath('../08-NanoFingerprint_check/');

%% Importing the NanoFingerprints

% Nanofingerprints folder
folder = '../07-StructuresAndGenerations/Generated_Nanofingerprints_others';

% List of files in the folder (just NV)
file_list = dir(fullfile(folder,'*NV.txt'));

% NanoFingerprint data matrix (rows for different
% NanoFingerprints, columns for NanoFingerprint values)
nanofingerprint = [];

% Loop through each file in the list
for i = 1:length(file_list)
    % Read each NanoFingerprint
    file_data = dlmread(fullfile(folder,file_list(i).name));

    % Append the NanoFingerprint to the matrix
    nanofingerprint = [nanofingerprint; file_data'];
end

nanofingerprint = sortrows(nanofingerprint,3);


%% PLOTS OF SIZE VS LOCAL STRUCTURES

if (strcmp(folder,'../07-StructuresAndGenerations/Generated_Nanofingerprints_others'))
    
    figure(1);
    sgtitle('Number of oxygen and metal atoms appearances over size for the ''other'' datasets');
    
    subplot(2,1,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,5),'.-');
    xlabel('Size (nm)');
    ylabel('O appearances');
    
    subplot(2,1,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,6),'.-');
    xlabel('Size (nm)');
    ylabel('M appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);
    
    figure(2);
    sgtitle('Number of oxygen and metal atoms appearances over size for the ''other'' datasets');
    
    subplot(2,2,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,8),'.-');
    xlabel('Size (nm)');
    ylabel('O(2) appearances');
    
    subplot(2,2,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,10),'.-');
    xlabel('Size (nm)');
    ylabel('O(4) appearances');
    
    subplot(2,2,3);
    plot(nanofingerprint(:,3),nanofingerprint(:,30),'.-');
    xlabel('Size (nm)');
    ylabel('O(0,3) appearances');
    
    subplot(2,2,4);
    plot(nanofingerprint(:,3),nanofingerprint(:,31),'.-');
    xlabel('Size (nm)');
    ylabel('O(0,4) appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);

    figure(2);
    sgtitle('Number of different local structure appearances over size for the ''other'' datasets');
    
    subplot(2,2,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,8),'.-');
    xlabel('Size (nm)');
    ylabel('O(2) appearances');
    
    subplot(2,2,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,10),'.-');
    xlabel('Size (nm)');
    ylabel('O(4) appearances');
    
    subplot(2,2,3);
    plot(nanofingerprint(:,3),nanofingerprint(:,30),'.-');
    xlabel('Size (nm)');
    ylabel('O(0,3) appearances');
    
    subplot(2,2,4);
    plot(nanofingerprint(:,3),nanofingerprint(:,31),'.-');
    xlabel('Size (nm)');
    ylabel('O(0,4) appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);

    figure(3);
    sgtitle('Number of different local structure appearances over size for the ''other'' datasets');
    
    subplot(1,2,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,23),'.-');
    xlabel('Size (nm)');
    ylabel('M(7) appearances');
    
    subplot(1,2,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,26),'.-');
    xlabel('Size (nm)');
    ylabel('M(10) appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);

else

    figure(1);
    sgtitle('Number of different local structure appearances over size for TiO_2');
    
    subplot(2,2,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,9),'.-');
    xlabel('Size (nm)');
    ylabel('O(3) appearances');
    
    subplot(2,2,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,26),'.-');
    xlabel('Size (nm)');
    ylabel('M(10) appearances');
    
    subplot(2,2,3);
    plot(nanofingerprint(:,3),nanofingerprint(:,30),'.-');
    xlabel('Size (nm)');
    ylabel('O(0,3) appearances');
    
    subplot(2,2,4);
    plot(nanofingerprint(:,3),nanofingerprint(:,218),'.-');
    xlabel('Size (nm)');
    ylabel('M(6,4) appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);
    
    figure(2);
    sgtitle('Number of oxygen and metal atoms appearances over size for TiO_2');
    
    subplot(2,1,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,5),'.-');
    xlabel('Size (nm)');
    ylabel('O appearances');
    
    subplot(2,1,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,6),'.-');
    xlabel('Size (nm)');
    ylabel('M appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);
    
    
    figure(3);
    sgtitle('Number of oxygen and metal atoms appearances over size for TiO_2');
    
    subplot(2,2,1);
    plot(nanofingerprint(:,3),nanofingerprint(:,19),'.-');
    xlabel('Size (nm)');
    ylabel('M(3) appearances');
    
    subplot(2,2,2);
    plot(nanofingerprint(:,3),nanofingerprint(:,182),'.-');
    xlabel('Size (nm)');
    ylabel('M(3,1) appearances');
    
    subplot(2,2,3);
    plot(nanofingerprint(:,3),nanofingerprint(:,193),'.-');
    xlabel('Size (nm)');
    ylabel('M(4,1) appearances');
    
    subplot(2,2,4);
    plot(nanofingerprint(:,3),nanofingerprint(:,204),'.-');
    xlabel('Size (nm)');
    ylabel('M(5,1) appearances');
    
    set(gcf, 'Position',  [100, 100, 1000, 450]);

end