function MAE = calculateMAE(y_pred,y_real)

    MAE = sum(abs(y_pred-y_real))./sum(y_real);
    % Replace NaNs by 0s
    MAE(isnan(MAE)) = 0;
    MAE(isinf(MAE)) = 0;
    MAE = sum(MAE)/size(MAE,2);

end