%% GENERATING NANOFINGERPRINTS FOR ATENA DATASET (Ti)

% It can be specified if it is used the XYZ with the variable use_xyz
% In case of using the XYZ, it can be specified the regression type (linear
% or quadratic)

clear;
close all;

addpath('../08-NanoFingerprint_check/');

%% Selection of parameters

% Starting index fingerprint (it will be used from n fingerprint to end)
n_start = 20;

% Number of training NanoFingerprints
n_train = 70;

% Using XYZ (use_xyz = 1) or not (use_xyz = 0)
use_xyz = 1;

% Regression type
if (use_xyz == 1)
    %type = 'linear';
    type = 'quadratic';
else
    type = 'quadratic';
end

% Number of training parameters (1 for size, 3 for size, O, M)
if (use_xyz == 1)
    m_predictor_params = 3;
else
    m_predictor_params = 1;
end

% Standardization before MLR (same results achieved)
standardize = 1;

% Shuffle rows (avoid any kind of sorting)
shuffle = 1;
rng('default') % For reproducibility

% Crossvalidation
crossvalidation = 1;
if (crossvalidation)
    K = 7;
end

%% Importing the NanoFingerprints

% Nanofingerprints folder
folder = '../07-StructuresAndGenerations/Generated_Nanofingerprints_Ti';

% List of files in the folder (just NV)
file_list = dir(fullfile(folder,'*NV.txt'));

% NanoFingerprint data matrix (rows for different
% NanoFingerprints, columns for NanoFingerprint values)
nanofingerprint = [];

% Loop through each file in the list
for i = 1:length(file_list)
    % Read each NanoFingerprint
    file_data = dlmread(fullfile(folder,file_list(i).name));

    % Append the NanoFingerprint to the matrix
    nanofingerprint = [nanofingerprint; file_data'];
end

%% Data preprocessing

% Order NanoFingerprint rows by its size
nanofingerprint = sortrows(nanofingerprint,3);

% Discarding columns: Shell, MAX and Atomic number (constants)
nanofingerprint_data = nanofingerprint(:,[3,5:end]);

% Discarding the first n NanoFingerprints (few size)
nanofingerprint_data_non_zero = nanofingerprint_data(n_start:end,:);

% Look for the columns in which all the values are 0 and save the indices
all_zero_columns = all(nanofingerprint_data_non_zero == 0,1);

% Create a new NanoFingerprint matrix just containing the non-zero columns
nanofingerprint_data_non_zero(:,all_zero_columns) = [];

% Standardize X by column
if (standardize == 1)
    mean_columns = mean(nanofingerprint_data_non_zero);
    std_columns = std(nanofingerprint_data_non_zero);
    nanofingerprint_data_non_zero = (nanofingerprint_data_non_zero-mean_columns)./std_columns;
else
    mean_columns = 0;
    std_columns = 0;
end

% Sorting rows
if (shuffle==1)
    numRows = size(nanofingerprint_data_non_zero,1);
    shuffleIndices = randperm(numRows);
    nanofingerprint_data_non_zero = nanofingerprint_data_non_zero(shuffleIndices, :);
end

%% Traning and test sets

% TRAINING

% Definition of the training predictors: Section 1
X_train = nanofingerprint_data_non_zero(1:n_train,1:m_predictor_params);
% Definition of the traning responses
y_train_real = nanofingerprint_data_non_zero(1:n_train,m_predictor_params+1:end);

% TESTING

% Definition of the testing predictors
X_test = nanofingerprint_data_non_zero(n_train+1:end,1:m_predictor_params);
% Definition of the test responses
y_test_real = nanofingerprint_data_non_zero(n_train+1:end,m_predictor_params+1:end);


%% Crossvalidation

if (crossvalidation == 1)
    rng('default') % For reproducibility
    cv = cvpartition(size(X_train,1),'KFold',K);
    
    NMSE_train_sum = 0;
    NMSE_test_sum = 0;
    MAE_train_sum = 0;
    MAE_test_sum = 0;
    NMSE_sum = 0;
    MAE_sum = 0;
    Err_avg_sum = 0;

    for i = 1:K
        % Selecting the training and validation sets
        idxValidation = cv.test(i);
        XValidation = X_train(idxValidation,:);
        yValidation = y_train_real(idxValidation,:);
        idxTrain = ~cv.test(i);
        Xtrain = X_train(idxTrain,:);
        ytrain = y_train_real(idxTrain,:);

        [~,~,~,NMSE_train,NMSE_test,MAE_train,MAE_test,NMSE,MAE, Err_avg] = compute_regression(type,nanofingerprint_data,nanofingerprint,Xtrain, ...
        XValidation, ytrain, yValidation, standardize, m_predictor_params,n_start, all_zero_columns, std_columns,mean_columns,shuffle);
        
        NMSE_train_sum = NMSE_train_sum + NMSE_train;
        NMSE_test_sum = NMSE_test_sum + NMSE_test;
        MPE_train_sum = MAE_train_sum + MAE_train;
        MPE_test_sum = MAE_test_sum + MAE_test;
        NMSE_sum = NMSE_sum + NMSE;
        MPE_sum = MAE_sum + MAE;
        Err_avg_sum = Err_avg_sum + Err_avg;

    end
    
    NMSE_train_sum = NMSE_train_sum/K;
    NMSE_test_sum = NMSE_test_sum/K;
    MAE_train_sum = MAE_train_sum/K;
    MAE_test_sum = MAE_test_sum/K;
    NMSE_sum = NMSE_sum/K;
    MAE_sum = MAE_sum/K;
    Err_avg_sum = Err_avg_sum/K;

    fprintf("NMSE training crossvalidation: %f\n", NMSE_train_sum);
    fprintf("NMSE validation crossvalidation: %f\n", NMSE_test_sum);
    fprintf("MAE training crossvalidation: %f\n", MAE_train_sum);
    fprintf("MAE validation crossvalidation: %f\n", MAE_test_sum);
    fprintf("NMSE after reconstruction crossvalidation: %f\n", NMSE_sum);
    fprintf("MAE after reconstruction crossvalidation: %f\n", MAE_sum);
    fprintf("Average error checking correctness crossvalidation: %f\n", Err_avg_sum);

end

%% Test set used 

rng('default');

if (crossvalidation == 1)
    [nanofingerprint_prediction, y_test_real, y_test_pred,NMSE_train,NMSE_test,MAE_train,MAE_test,NMSE,MAE, Err_avg] = compute_regression(type,nanofingerprint_data,nanofingerprint,Xtrain, ...
    [XValidation;X_test], ytrain, [yValidation;y_test_real], standardize, m_predictor_params,n_start, all_zero_columns, std_columns,mean_columns,shuffle);
else
    [nanofingerprint_prediction, y_test_real, y_test_pred,NMSE_train,NMSE_test,MAE_train,MAE_test,NMSE,MAE, Err_avg] = compute_regression(type,nanofingerprint_data,nanofingerprint,X_train, ...
    X_test, y_train_real, y_test_real, standardize, m_predictor_params,n_start, all_zero_columns, std_columns,mean_columns,shuffle);
end

fprintf("NMSE training: %f\n", NMSE_train);
fprintf("NMSE test: %f\n", NMSE_test);
fprintf("MAE training: %f\n", MAE_train);
fprintf("MAE test: %f\n", MAE_test);
fprintf("NMSE after reconstruction: %f\n", NMSE);
fprintf("MAE after reconstruction: %f\n", MAE);
fprintf("Average error checking correctness: %f\n", Err_avg);

%% PLOTS OF THE RESULTS

% Plotting the real values vs the predicted ones
figure(1);

sgtitle('Scatter plot of real values vs. predicted values for the test set of TiO_2');

subplot(2,2,1);
output_variable = 5-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for O(3)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

subplot(2,2,2);
output_variable = 13-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for M(10)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

subplot(2,2,3);
output_variable = 16-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for the test set for O(0,3)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

subplot(2,2,4);
output_variable = 31-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for M(6,4)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

set(gcf, 'Position',  [100, 100, 1000, 450]);

figure(2);

sgtitle('Scatter plot of real values vs. predicted values for the test set of TiO_2');

subplot(2,2,1);
output_variable = 6-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for M(3)' newline]);
line;
% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

subplot(2,2,2);
output_variable = 19-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for M(3,1)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

subplot(2,2,3);
output_variable = 22-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for M(4,1)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

subplot(2,2,4);
output_variable = 25-m_predictor_params+1;

scatter(y_test_real(:,output_variable),y_test_pred(:,output_variable));

xlabel('y_r_e_a_l');
ylabel('y_p_r_e_d');
title(['Representation for M(5,1)' newline]);

% Lineal regression
c=polyfit(y_test_real(:,output_variable)',y_test_pred(:,output_variable)',1);
Gp=polyval(c,y_test_real(:,output_variable)');
hold on;
plot(y_test_real(:,output_variable)',Gp,'r');

legend('Scatter plot','Linear regression','Location','southeast');

set(gcf, 'Position',  [100, 100, 1000, 450]);

figure(3);

sgtitle('Representation of Real values and predicted values for each test pattern of TiO_2');

subplot(2,2,1);
output_variable = 5-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for O(3)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

subplot(2,2,2);
output_variable = 13-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for M(10)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

subplot(2,2,3);
output_variable = 16-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for O(0,3)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

subplot(2,2,4);
output_variable = 31-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for M(6,4)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

set(gcf, 'Position',  [100, 100, 1000, 450]);

figure(4);

sgtitle('Representation of Real values and predicted values for each test pattern of TiO_2');

subplot(2,2,1);
output_variable = 6-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for M(3)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

subplot(2,2,2);
output_variable = 19-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for M(3,1)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

subplot(2,2,3);
output_variable = 22-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for M(4,1)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

subplot(2,2,4);
output_variable = 25-m_predictor_params+1;

pat = 1:1:size(y_test_real(:,output_variable)',2);
plot(pat,y_test_real(:,output_variable)','-*','Color','k');
hold on;
plot(pat,y_test_pred(:,output_variable)','--o','LineWidth',2);
xlabel('Validation/Test Pattern');
ylabel('Appearances');
title(['Representation for M(5,1)' newline]);
legend('Real','Prediction','Location','southeast','Location','northeast');

set(gcf, 'Position',  [100, 100, 1000, 450]);

figure(5);

sgtitle('Number of oxygen and metal atoms appearances over size for TiO_2');

subplot(2,1,1);
output_variable = 5;
plot(nanofingerprint(n_start:end,3),nanofingerprint(n_start:end,output_variable),'Color','Blue');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(1:n_train),3),nanofingerprint_prediction(shuffleIndices(1:n_train),output_variable),'g*');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(n_train+1:end),3),nanofingerprint_prediction(shuffleIndices(n_train+1:end),output_variable),'r*');
xlabel('Size (nm)');
ylabel('O Appearances');
legend('Real','Train data prediction', 'Test data prediction','Location','southeast');

subplot(2,1,2);
output_variable = 6;
plot(nanofingerprint(n_start:end,3),nanofingerprint(n_start:end,output_variable),'Color','Blue');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(1:n_train),3),nanofingerprint_prediction(shuffleIndices(1:n_train),output_variable),'g*');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(n_train+1:end),3),nanofingerprint_prediction(shuffleIndices(n_train+1:end),output_variable),'r*');
xlabel('Size (nm)');
ylabel('M Appearances');
legend('Real','Train data prediction', 'Test data prediction','Location','southeast');

set(gcf, 'Position',  [100, 100, 1000, 450]);

figure(6);

sgtitle('Number of different local structure appearances over size for TiO_2');

subplot(4,1,1);
output_variable = 30;
plot(nanofingerprint(n_start:end,3),nanofingerprint(n_start:end,output_variable),'Color','Blue');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(1:n_train),3),nanofingerprint_prediction(shuffleIndices(1:n_train),output_variable),'g*');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(n_train+1:end),3),nanofingerprint_prediction(shuffleIndices(n_train+1:end),output_variable),'r*');
xlabel('Size (nm)');
ylabel('O(0,3) Appearances');
legend('Real','Train data prediction', 'Test data prediction','Location','southeast');

subplot(4,1,2);
output_variable = 182;
plot(nanofingerprint(n_start:end,3),nanofingerprint(n_start:end,output_variable),'Color','Blue');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(1:n_train),3),nanofingerprint_prediction(shuffleIndices(1:n_train),output_variable),'g*');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(n_train+1:end),3),nanofingerprint_prediction(shuffleIndices(n_train+1:end),output_variable),'r*');
xlabel('Size (nm)');
ylabel('M(3,1) Appearances');
legend('Real','Train data prediction', 'Test data prediction','Location','southeast');

subplot(4,1,3);
output_variable = 193;
plot(nanofingerprint(n_start:end,3),nanofingerprint(n_start:end,output_variable),'Color','Blue');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(1:n_train),3),nanofingerprint_prediction(shuffleIndices(1:n_train),output_variable),'g*');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(n_train+1:end),3),nanofingerprint_prediction(shuffleIndices(n_train+1:end),output_variable),'r*');
xlabel('Size (nm)');
ylabel('M(4,1) Appearances');
legend('Real','Train data prediction', 'Test data prediction','Location','southeast');

subplot(4,1,4);
output_variable = 204;
plot(nanofingerprint(n_start:end,3),nanofingerprint(n_start:end,output_variable),'Color','Blue');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(1:n_train),3),nanofingerprint_prediction(shuffleIndices(1:n_train),output_variable),'g*');
hold on;
plot(nanofingerprint_prediction(shuffleIndices(n_train+1:end),3),nanofingerprint_prediction(shuffleIndices(n_train+1:end),output_variable),'r*');
xlabel('Size (nm)');
ylabel('M(5,1) Appearances');
legend('Real','Train data prediction', 'Test data prediction','Location','southeast');

set(gcf, 'Position',  [100, 100, 1000, 450]);