%% Regression and Error calculation program

% Performing a regression with fitlm (specifying the type)
% It includes the constant term, the Intercept
% Includes calculation of errors

function [nanofingerprint_prediction, y_test_real, y_test_pred,NMSE_train,NMSE_test,MAE_train,MAE_test,NMSE,MAE, Err_avg] = compute_regression(type,nanofingerprint_data,nanofingerprint,X_train, X_test, y_train_real, y_test_real, standardize, m_predictor_params,n_start,all_zero_columns,std_columns,mean_columns,shuffle)

    models = cell(size(y_train_real, 2), 1);
    
    for i = 1:size(y_train_real, 2)
        models{i} = fitlm(X_train, y_train_real(:, i),type);
    end
    
    % Predicting the train outputs with predict
    
    for i = 1:size(y_train_real, 2)
        y_train_pred(:, i) = predict(models{i}, X_train);
    end
    
    % Predicting the test outputs with predict
    for i = 1:size(y_test_real, 2)
        y_test_pred(:, i) = predict(models{i}, X_test);
    end
    
    if (standardize == 1)
        y_train_pred = (y_train_pred .* std_columns(:,m_predictor_params+1:end)) + mean_columns(:,m_predictor_params+1:end);
        y_test_pred = (y_test_pred .* std_columns(:,m_predictor_params+1:end)) + mean_columns(:,m_predictor_params+1:end);
    end
    
    % Rouding the outputs (must be integers)
    y_train_pred = round(y_train_pred);
    y_test_pred = round(y_test_pred);
    
    % Convert negative values to 0
    y_train_pred=max(y_train_pred,0);
    y_test_pred=max(y_test_pred,0);
    
    %% NMSE and MAE results
    
    if (standardize == 1)
        y_train_real = (y_train_real .* std_columns(:,m_predictor_params+1:end)) + mean_columns(:,m_predictor_params+1:end);
        y_test_real = (y_test_real .* std_columns(:,m_predictor_params+1:end)) + mean_columns(:,m_predictor_params+1:end);
    end

    % Rounding decimal values due to standardization
    y_train_real = round(y_train_real);
    y_test_real = round(y_test_real);
    
    NMSE_train = calculateNNMSE(y_train_real,y_train_pred);
    NMSE_test = calculateNNMSE(y_test_real,y_test_pred);
    
    MAE_train = calculateMae(y_train_pred,y_train_real);
    MAE_test = calculateMae(y_test_pred,y_test_real);
   
    
    %% FINGERPRINT RECONSTRUCTION
    
    if (standardize == 1)
        X_train = (X_train .* std_columns(:,1:m_predictor_params)) + mean_columns(:,1:m_predictor_params);
        X_test = (X_test .* std_columns(:,1:m_predictor_params)) + mean_columns(:,1:m_predictor_params);
    end
    
    nanofingerprint_data_non_zero_predicted = [X_train y_train_pred; X_test y_test_pred];
    
    % Restore the original order of rows
    if (shuffle==1)
        nanofingerprint_data_non_zero_predicted = sortrows(nanofingerprint_data_non_zero_predicted,1);
    end
    
    nanofingerprint_prediction = zeros(size(nanofingerprint_data(n_start:n_start+size(X_train,1)+size(X_test,1)-1,:)));
    
    % Restore zero columns
    for i = 1:size(nanofingerprint_prediction,1)
        nanofingerprint_prediction(i,all_zero_columns == 0) = nanofingerprint_data_non_zero_predicted(i,:);
    end
    
    % Add the Thickness, Max and Atomic (if it was eliminated) columns from the original nanofingerprint
    nanofingerprint_prediction = [nanofingerprint(n_start:n_start+size(X_train,1)+size(X_test,1)-1,1:4) nanofingerprint_prediction(:,2:end)];
    
    NMSE = calculateNNMSE(nanofingerprint(n_start:n_start+size(X_train,1)+size(X_test,1)-1,:),nanofingerprint_prediction);
    
    MAE = calculateMae(nanofingerprint_prediction,nanofingerprint(n_start:n_start+size(X_train,1)+size(X_test,1)-1,:));
        
    %% CHECK NEW NANOFINGERPRINTS CORRECTNESS
    
    for i = 1:size(nanofingerprint_prediction)
        errors(i) = check_NanoFingerprint(nanofingerprint_prediction(i,:)');
    end
    
    Err_avg = sum(errors)/size(errors,2);
    
end