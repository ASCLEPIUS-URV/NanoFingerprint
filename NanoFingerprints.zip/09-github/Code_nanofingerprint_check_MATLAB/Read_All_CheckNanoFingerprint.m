clear
close all
clc

% Nanofingerprints folder
folder = '../07-StructuresAndGenerations/Generated_Nanofingerprints_Ti';

%% Importing the NanoFingerprint

% List of files in the folder (just NV)
file_list = dir(fullfile(folder,'*NV.txt'));

% Loop through each file in the list
for i = 1:length(file_list)
    
    % Read each NanoFingerprint
    NanoFingerprint = dlmread(fullfile(folder,file_list(i).name));
    
    % Obtaining the result

    errors(i) =  check_NanoFingerprint(NanoFingerprint);

    fprintf('Structural NanoFingerprint: %s\n',file_list(i).name);
    fprintf('The number of errors are: %d\n',errors);

end

Average_error = sum(errors)/size(errors,2);

fprintf('\nAverage Error: %f\n',Average_error);
