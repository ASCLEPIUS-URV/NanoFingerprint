%% NanoFingerprint correctness checking function

function [errors, message] = check_NanoFingerprint(NanoFingerprint)

    % Section arrays
    
    MAX = NanoFingerprint(2);
    
    O_appearances = NanoFingerprint(5);
    M_appearances = NanoFingerprint(6);
    
    pos = 7;
    Section2_length = 2*MAX;
    Section2 = NanoFingerprint(pos:pos+Section2_length-1);
    
    pos = pos + Section2_length;
    Section3_length = 2*(MAX+1)^2;
    Section3 = NanoFingerprint(pos:pos+Section3_length-1);
    
    pos = pos + Section3_length;
    Section4_length = 3*(MAX+1)^4;
    Section4 = NanoFingerprint(pos:pos+Section4_length-1);
    
    %% NanoFingerprint correctness checking
    
    errors = 0;
    message = "";
    
    %% Checking length

    len = 6 + Section2_length + Section3_length + Section4_length;

    if (size(NanoFingerprint,1) ~= len)
        errors = errors + 1;
        message = [message "\nError in size."];
    end

    %% Checking Section 2
    
    O_sum = sum(Section2(1:MAX));
    
    if (O_sum > O_appearances)
        errors = errors + 1;
        message = [message "\nError in Section 2, number of O."];
    end
    
    M_sum = sum(Section2(MAX+1:Section2_length));
    
    if (M_sum > M_appearances)
        errors = errors + 1;
        message = [message "\nError in Section 2, number of M."];
    end
    
    %% Checking Section 3
    
    nonZeroIndices = find(Section3 ~= 0);
    
    Section2_from_Section3 = zeros(2*MAX,1);
    
    for n = 1:size(nonZeroIndices,1)
    
        index =  nonZeroIndices(n) - 1;
        
        if (index > (MAX+1)^2)
            index = index - (MAX+1)^2;
            part = 2;
        else
            part = 1;
        end
        
        second_digit = mod(index,MAX+1);
        index = idivide(int64(index),int64(MAX+1));
        first_digit = mod(index,MAX+1);
        
        if ((first_digit + second_digit <= MAX) && (first_digit + second_digit ~= 0))
            index_Section2 = first_digit + second_digit;
        
            if (part == 2)
                index_Section2 = index_Section2 + MAX;
            end
        
            Section2_from_Section3(index_Section2) = Section2_from_Section3(index_Section2) + Section3(nonZeroIndices(n));
            
        else
            errors = errors + 1;
            message = [message "\nError in Section 3, number of bonds is > MAX or 0."];
        end
    
    end
    
    errors = errors + sum(Section2_from_Section3 ~= Section2);
    
    if (sum(Section2_from_Section3 ~= Section2) ~= 0)
        message = [message "\nError in Section 3."];
    end
    
    %% Checking Section 4
    
    nonZeroIndices = find(Section4 ~= 0) - 1;
    
    for n = 1:size(nonZeroIndices,1)
    
        index =  nonZeroIndices(n);
    
        if (index<=2*(MAX+1)^4 && index > (MAX+1)^4)
            index = index - (MAX+1)^4 - 1;
            part = 2;
        elseif (index > 2*(MAX+1)^4)
            index = index - 2*(MAX+1)^4 - 1;
            part = 3;
        else
            part = 1;
        end
        
        fourth_digit = mod(index,MAX+1);
        index = idivide(int64(index),int64(MAX+1));
        third_digit = mod(index,MAX+1);
        index = idivide(int64(index),int64(MAX+1));
        second_digit = mod(index,MAX+1);
        index = idivide(int64(index),int64(MAX+1));
        first_digit = mod(index,MAX+1);
        
        index_Section3_first_element = (MAX+1)*first_digit + second_digit + 1;
        index_Section3_second_element = (MAX+1)*third_digit + fourth_digit + 1;
        
        if (part == 2)
            index_Section3_first_element = index_Section3_first_element+(MAX+1)^2;
            index_Section3_second_element = index_Section3_second_element+(MAX+1)^2;
        elseif (part == 3)
            index_Section3_second_element = index_Section3_second_element+(MAX+1)^2;
        end
        
        %if (Section4(nonZeroIndices(n)) > Section3(index_Section3_first_element) + Section3(index_Section3_second_element))
        %    errors = errors + 1;
        %end
    
        if (Section3(index_Section3_first_element) == 0)
            errors = errors + 1;
            message = [message "\nError in Section 4, first local structure."];
        end
    
        if (Section3(index_Section3_second_element) == 0)
            errors = errors + 1;
            message = [message "\nError in Section 4, second local structure."];
        end
    
    end  

end