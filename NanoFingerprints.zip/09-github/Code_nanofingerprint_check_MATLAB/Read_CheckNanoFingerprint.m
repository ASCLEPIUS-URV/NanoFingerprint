clear
close all
clc

NanoFingerprint_file = 'TiO2_002_nanofingerprint_10_NV.txt';

%% Importing the NanoFingerprint

name = NanoFingerprint_file;

NanoFingerprint_file = ['../07-StructuresAndGenerations/Generated_Nanofingerprints_Ti/' NanoFingerprint_file];

fileID = fopen(NanoFingerprint_file,'r');
formatSpec = '%f';
NanoFingerprint = fscanf(fileID,formatSpec);

%% Obtaining the result

errors =  check_NanoFingerprint(NanoFingerprint);

fprintf('Structural NanoFingerprint: %s\n',name);
fprintf('The number of errors are: %d\n',errors);