CODI

Dins la carpeta 'Code':

El main és el programa nanofingerprint_generator_main.c

Les funcions utilizades estan a functions.c

Capçaleres de les funcions, i includes, estan a functions.h

Les estructures definides estan a struct.h

COMPILAR I CREAR EXECUTABLE en MacOS

Primer, anar a la carpeta 'Code', utilitzant la instrucció 'cd'.

Un cop allà, fer:

gcc nanofingerprint_generator_main.c functions.c -o nanofingerprint_generator_main

En aquest cas, hem anomenat el programa 'nanofingerprint_generator_main', però el podem anomenar com vulguem.

Es generarà arxiu executable a la carpeta Code.

CRIDAR PROGRAMA

Anar a la carpeta Code, utilitzant la instrucció 'cd'.

Un cop allà, fer, per exemple:

./nanofingerprint_generator_main Al2O3_013.xyz 100 5

Paràmetres:
1. Graph (xyz).
2. Thickness (nm)
3. Nombre màxim d'enllaços (max_bonds).

ALTRES

Els NanoFingerprints generats aniran a parar a la carpeta 'Generated_NanoFingerprints'.

Les estructures XYZ s'han de col·locar a la carpeta 'Structures_xyz'.

Per realitzar múltiples generacions, cal fer el següent codi des del Terminal:

for file in ../Structures_xyz/*.xyz 
do
./nanofingerprint_generator_main "$(basename "$file")" 100 10
printf "$(basename "$file")\n"
done
