#ifndef FUNCIONS_H_INCLUDED
#define FUNCIONS_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> 
#include <stdbool.h>
#include <math.h>
#include <stdbool.h>

#include "structs.h"

#define atomic_O 8
#define E 4

int toAtomic(char element[2]);

float distAtom(int a1, int a2);

float calculateDistance(float x1, float y1, float z1, float x2, float y2, float z2);

int graphToThickness(char graph[100], float thickness, char out[100], double *dist_max, int *num_atoms_new_graph);

void countOM(int *atomics, int atomics_size, int *O_appearances, int *M_appearances);

int countO(int *atomics, int atomics_size);

void calculateIndices(int init, int index, int max_bonds, int *a, int *b, int *c, int *d);

int generateNanofingerprint(char nano_file[100], int max_bons, float *section1, int *section2, int *section3, int *section4, char verbose[4]);

void getTime(struct timespec start, struct timespec end, double *execution_time, int *hours, int *min, int *sec, int *ms);

void writecsv(char file_name[100], char graph[100], int value, double time);

/*******************************************************************************
	Graph functions
********************************************************************************/

struct node *createNode(int v);

struct Graph *createGraph(int vertices);

void addEdge(struct Graph *graph, int node_s, int node_d);

void addAtomic(struct Graph *graph, int node, int atomic);

void setShell(struct Graph *graph, int node);

int isShell(struct Graph *graph, int node);

void printGraph(struct Graph *graph);

int numVertices(struct Graph *graph);

int degreeOfNode(struct Graph *graph, int node);

int atomicOfNode(struct Graph *graph, int node);

int *getAtomics(struct Graph *graph);

int *getSurroundingNodesAtomic(struct Graph *graph, int node);

int *getSurroundingNodes(struct Graph *graph, int node);

bool isNeighbour(struct Graph *graph, int node1, int node2);

int xyzToGraph(char entry[100], int *atomic, struct Graph *graph, double size, double thickness);

/*******************************************************************************
	Local Structure functions
********************************************************************************/

struct localStructure *createLocalStructure(int atomic, int O_connections, int M_connections);

struct localStructureList *createLocalStructureList(int maxElements);

void addLocalStructure(struct localStructureList *localStructureList, struct localStructure *localStructure, int n);

int getNumLocalStructures(struct localStructureList *localStructureList);

void printLocalStructureList(struct localStructureList *localStructureList);

int getNodeAtPosition(struct localStructureList *localStructureList, int position);

int getAtomic(struct localStructure *localStructure);

int getO_connections(struct localStructure *localStructure);

int getM_connections(struct localStructure *localStructure);

int reverseIndices(int index, int max_bonds);

bool hasToReverse(struct localStructure *localStructure_1, struct localStructure *localStructure_2);

void addElement(struct localStructureList *localStructureList, int *section4, int max_bonds, int pos_1, int pos_2);

#endif /*FUNCIONS_H_INCLUDED*/