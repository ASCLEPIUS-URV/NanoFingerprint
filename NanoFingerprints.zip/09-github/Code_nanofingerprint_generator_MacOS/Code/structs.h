#ifndef STRUCTS_H_INCLUDED
#define STRUCTS_H_INCLUDED

/*******************************************************************************
	Graph structs
********************************************************************************/

// Node struct
struct node {
  int vertex;
  struct node *next;
};

// Graph struct
struct Graph {
  int numVertices;
  int *atomic_numbers;
  int *degree;
  int *shell;
  struct node **adjLists;
};

/*******************************************************************************
	Local Structure structs
********************************************************************************/

// Local Structure struct
// Composed by atomic number of central element, bonds with Oxygen, bonds with Metal
struct localStructure {
  int atomic;
  int O_connections;
  int M_connections;
};

// Local Structure List struct
struct localStructureList {
  int numLocalStructures;
  int *node;
  struct localStructure **list;
};

#endif /*STRUCTS_H_INCLUDED*/