#include "functions.h"

int toAtomic(char element[2])
{
	int atomic;

	if (!strcmp(element,"H")) {
		atomic=1;
	} else if (!strcmp(element,"He")) {
		atomic=2;
	} else if (!strcmp(element,"Li")) {
		atomic=3;
	} else if (!strcmp(element,"Be")) {
		atomic=4;
	} else if (!strcmp(element,"B")) {
		atomic=5;
	} else if (!strcmp(element,"C")) {
		atomic=6;
	} else if (!strcmp(element,"N")) {
		atomic=7;
	} else if (!strcmp(element,"O")) {
		atomic=8;
	} else if (!strcmp(element,"F")) {
		atomic=9;
	} else if (!strcmp(element,"Ne")) {
		atomic=10;
	} else if (!strcmp(element,"Na")) {
		atomic=11;
	} else if (!strcmp(element,"Mg")) {
		atomic=12;
	} else if (!strcmp(element,"Al")) {
		atomic=13;
	} else if (!strcmp(element,"Si")) {
		atomic=14;
	} else if (!strcmp(element,"P")) {
		atomic=15;
	} else if (!strcmp(element,"S")) {
		atomic=16;
	} else if (!strcmp(element,"Cl")) {
		atomic=17;
	} else if (!strcmp(element,"Ar")) {
		atomic=18;
	} else if (!strcmp(element,"K")) {
		atomic=19;
	} else if (!strcmp(element,"Ca")) {
		atomic=20;
	} else if (!strcmp(element,"Sc")) {
		atomic=21;
	} else if (!strcmp(element,"Ti")) {
		atomic=22;
	} else if (!strcmp(element,"V")) {
		atomic=23;
	} else if (!strcmp(element,"Cr")) {
		atomic=24;
	} else if (!strcmp(element,"Mn")) {
		atomic=25;
	} else if (!strcmp(element,"Fe")) {
		atomic=26;
	} else if (!strcmp(element,"Co")) {
		atomic=27;
	} else if (!strcmp(element,"Ni")) {
		atomic=28;
	} else if (!strcmp(element,"Cu")) {
		atomic=29;
	} else if (!strcmp(element,"Zn")) {
		atomic=30;
	} else if (!strcmp(element,"Ga")) {
		atomic=31;
	} else if (!strcmp(element,"Ge")) {
		atomic=32;
	} else if (!strcmp(element,"As")) {
		atomic=33;
	} else if (!strcmp(element,"Se")) {
		atomic=34;
	} else if (!strcmp(element,"Br")) {
		atomic=35;
	} else if (!strcmp(element,"Kr")) {
		atomic=36;
	} else if (!strcmp(element,"Rb")) {
		atomic=37;
	} else if (!strcmp(element,"Sr")) {
		atomic=38;
	} else if (!strcmp(element,"Y")) {
		atomic=39;
	} else if (!strcmp(element,"Zr")) {
		atomic=40;
	} else if (!strcmp(element,"Nb")) {
		atomic=41;
	} else if (!strcmp(element,"Mo")) {
		atomic=42;
	} else if (!strcmp(element,"Tc")) {
		atomic=43;
	} else if (!strcmp(element,"Ru")) {
		atomic=44;
	} else if (!strcmp(element,"Rh")) {
		atomic=45;
	} else if (!strcmp(element,"Pd")) {
		atomic=46;
	} else if (!strcmp(element,"Ag")) {
		atomic=47;
	} else if (!strcmp(element,"Cd")) {
		atomic=48;
	} else if (!strcmp(element,"In")) {
		atomic=49;
	} else if (!strcmp(element,"Sn")) {
		atomic=50;
	} else if (!strcmp(element,"Sb")) {
		atomic=51;
	} else if (!strcmp(element,"Te")) {
		atomic=52;
	} else if (!strcmp(element,"I")) {
		atomic=53;
	} else if (!strcmp(element,"Xe")) {
		atomic=54;
	} else if (!strcmp(element,"Cs")) {
		atomic=55;
	} else if (!strcmp(element,"Ba")) {
		atomic=56;
	} else if (!strcmp(element,"La")) {
		atomic=57;
	} else if (!strcmp(element,"Ce")) {
		atomic=58;
	} else if (!strcmp(element,"Pr")) {
		atomic=59;
	} else if (!strcmp(element,"Nd")) {
		atomic=60;
	} else if (!strcmp(element,"Pm")) {
		atomic=61;
	} else if (!strcmp(element,"Sm")) {
		atomic=62;
	} else if (!strcmp(element,"Eu")) {
		atomic=63;
	} else if (!strcmp(element,"Gd")) {
		atomic=64;
	} else if (!strcmp(element,"Tb")) {
		atomic=65;
	} else if (!strcmp(element,"Dy")) {
		atomic=66;
	} else if (!strcmp(element,"Ho")) {
		atomic=67;
	} else if (!strcmp(element,"Er")) {
		atomic=68;
	} else if (!strcmp(element,"Tm")) {
		atomic=69;
	} else if (!strcmp(element,"Yb")) {
		atomic=70;
	} else if (!strcmp(element,"Lu")) {
		atomic=71;
	} else if (!strcmp(element,"Hf")) {
		atomic=72;
	} else if (!strcmp(element,"Ta")) {
		atomic=73;
	} else if (!strcmp(element,"W")) {
		atomic=74;
	} else if (!strcmp(element,"Re")) {
		atomic=75;
	} else if (!strcmp(element,"Os")) {
		atomic=76;
	} else if (!strcmp(element,"Ir")) {
		atomic=77;
	} else if (!strcmp(element,"Pt")) {
		atomic=78;
	} else if (!strcmp(element,"Au")) {
		atomic=79;
	} else if (!strcmp(element,"Hg")) {
		atomic=80;
	} else if (!strcmp(element,"Tl")) {
		atomic=81;
	} else if (!strcmp(element,"Pb")) {
		atomic=82;
	} else if (!strcmp(element,"Bi")) {
		atomic=83;
	} else if (!strcmp(element,"Po")) {
		atomic=84;
	} else if (!strcmp(element,"At")) {
		atomic=85;
	} else if (!strcmp(element,"Rn")) {
		atomic=86;
	} else if (!strcmp(element,"Fr")) {
		atomic=87;
	} else if (!strcmp(element,"Ra")) {
		atomic=88;
	} else if (!strcmp(element,"Ac")) {
		atomic=89;
	} else if (!strcmp(element,"Th")) {
		atomic=90;
	} else if (!strcmp(element,"Pa")) {
		atomic=91;
	} else if (!strcmp(element,"U")) {
		atomic=92;
	} else if (!strcmp(element,"Np")) {
		atomic=93;
	} else if (!strcmp(element,"Pu")) {
		atomic=94;
	} else if (!strcmp(element,"Am")) {
		atomic=95;
	} else if (!strcmp(element,"Cm")) {
		atomic=96;
	} else if (!strcmp(element,"Bk")) {
		atomic=97;
	} else if (!strcmp(element,"Cf")) {
		atomic=98;
	} else if (!strcmp(element,"Es")) {
		atomic=99;
	} else if (!strcmp(element,"Fm")) {
		atomic=100;
	} else if (!strcmp(element,"Md")) {
		atomic=101;
	} else if (!strcmp(element,"No")) {
		atomic=102;
	} else if (!strcmp(element,"Lr")) {
		atomic=103;
	} else if (!strcmp(element,"Rf")) {
		atomic=104;
	} else if (!strcmp(element,"Db")) {
		atomic=105;
	} else if (!strcmp(element,"Sg")) {
		atomic=106;
	} else if (!strcmp(element,"Bh")) {
		atomic=107;
	} else if (!strcmp(element,"Hs")) {
		atomic=108;
	} else if (!strcmp(element,"Mt")) {
		atomic=109;
	} else if (!strcmp(element,"Ds")) {
		atomic=110;
	} else if (!strcmp(element,"Rg")) {
		atomic=111;
	} else if (!strcmp(element,"Cn")) {
		atomic=112;
	} else if (!strcmp(element,"Nh")) {
		atomic=113;
	} else if (!strcmp(element,"Fl")) {
		atomic=114;
	} else if (!strcmp(element,"Mc")) {
		atomic=115;
	} else if (!strcmp(element,"Lv")) {
		atomic=116;
	} else if (!strcmp(element,"Ts")) {
		atomic=117;
	} else if (!strcmp(element,"Og")) {
		atomic=118;
	} else {
		atomic=-1;
	}
	return atomic;
}

float distAtom(int a1, int a2)
{
	float dist_atom=2.2;
	if (a1==a2)	
	{
		switch (a1)
		{
			case 8:
				dist_atom=1.8;
				break;
			case 22:
				dist_atom=3;
				break;
			case 30:
				dist_atom=3.5;
				break;
			case 26:
				dist_atom=3.7;
				break;
			case 13:
				dist_atom=2.86;
				break;
			case 29:
				dist_atom=3.1;
				break;
			case 49:
				dist_atom = 3.5;
				break;
			case 57:
				dist_atom=4;
				break;
			case 14:
				dist_atom=2.5;
				break;
			case 40:
				dist_atom=3.5;
				break;
			case 39:
				dist_atom=3.6;
				break;
			}
	}
	else
	{
		if ((a1==22 && a2==8) || (a1==8 && a2==22))
		{
			dist_atom=2.35;
		}
		else if ((a1==30 && a2==8) || (a1==8 && a2==30))
		{
			dist_atom=2.11;
		}
		else if ((a1==8 && a2==26) || (a1==26 && a2==8))
		{
			dist_atom=3.5;
		}
		else if ((a1==8 && a2==13) || (a1==13 && a2==8))
		{
			dist_atom=2.2;
		}
		else if ((a1==8 && a2==29) || (a1==29 && a2==8))
		{
			dist_atom=3.9;
		}
		else if ((a1==8 && a2==49) || (a1==49 && a2==8))
		{
			dist_atom=2.4;
		}
		else if ((a1==8 && a2==83) || (a1==83 && a2==8))
		{
			dist_atom=3.1;
		}
		else if ((a1==8 && a2==57) || (a1==57 && a2==8))
		{
			dist_atom=3;
		}
		else if ((a1==8 && a2==51) || (a1==51 && a2==8))
		{
			dist_atom=2.7;
		}
		else if ((a1==8 && a2==14) || (a1==14 && a2==8))
		{
			dist_atom=1.9;
		}
		else if ((a1==8 && a2==40) || (a1==40 && a2==8))
		{
			dist_atom=2.3;
		}
		else if ((a1==8 && a2==39) || (a1==39 && a2==8))
		{
			dist_atom=2.3;
		}
	}
	return dist_atom;
}

float calculateDistance(float x1,float y1,float z1,float x2,float y2,float z2)
{
	float distance;
	
	distance=sqrt((pow(x2-x1,2))+(pow(y2-y1,2))+(pow(z2-z1,2)));
	return distance;	
}

int graphToThickness (char graph[100], float thickness, char out[100], double *dist_max, int *num_atoms_new_graph)
{
	char line[150];
	float suma_x=0,suma_y=0,suma_z=0,x,y,z,dist,a;
	int numatoms,err=0,new_atom=0;
	FILE *f,*g;

	float **positions;
	int *list;

	f=fopen(graph,"r");
	g=fopen(out,"w");
	if (f==NULL)
	{	
		err=-1;
	}
	else
	{
		if (g==NULL)
		{	
			err=-2;
		}
		else
		{
			fscanf(f,"%d\n",&numatoms);
			positions=(float **)malloc(numatoms*sizeof(float*));
			if (positions==NULL)
			{
				err=-4;
			}
			else
			{
				for (int i=0;i<numatoms;i++)
				{
					positions[i]=(float*)malloc(3*sizeof(float));
				}
				if (positions==NULL)
				{
					err=-4;
				}
				else
				{
					list=(int *)malloc(numatoms*sizeof(int));
					if (list==NULL)
					{
						err=-4;
					}
					else
					{
						memset(list, 0, numatoms*sizeof(int));
						fgets(line,20,f);
						fscanf(f,"%s",line);
						for (int i=0;!feof(f);i++)
						{
							fscanf(f,"%f",&x);
							positions[i][0]=x;
							fscanf(f,"%f",&y);
							positions[i][1]=y;
							fscanf(f,"%f\n",&z);
							positions[i][2]=z;
							fscanf(f,"%s",line);
							suma_x=suma_x+x;
							suma_y=suma_y+y;
							suma_z=suma_z+z;
						}
						suma_x=suma_x/numatoms;
						suma_y=suma_y/numatoms;
						suma_z=suma_z/numatoms;
						for (int i=0; i<numatoms;i++)
						{
							dist=calculateDistance(positions[i][0],positions[i][1],positions[i][2],suma_x,suma_y,suma_z);
							if(dist>*dist_max)
							{
								*dist_max=dist; 
							}

						}
						a=*dist_max-(thickness+E);
						for (int i=0; i<numatoms;i++)
						{
							if (calculateDistance(positions[i][0],positions[i][1],positions[i][2],suma_x,suma_y,suma_z)>a)
							{
								list[i]=1;
								new_atom++;
							}
						}
						if (new_atom==0)
						{
							err=-3;
						}
						else
						{
							fprintf(g,"%d\n",new_atom);
							*num_atoms_new_graph = new_atom;
							rewind(f);
							fscanf(f,"%d\n",&numatoms);
							fgets(line,20,f);
							line[strlen(line)-2]='\0';
							strcat(line,"_thickness");
							fprintf(g,"%s\n",line);
							for (int i=0;new_atom!=0;i++)
							{
								if (list[i]==1)
								{
									fgets(line,150,f);
									fprintf(g,"%s",line);
									new_atom--;
								}
								else
								{
									fgets(line,150,f);
								}
							}
						}
						free(list);
					}
					free(positions);
				}
			}
			fclose(g);
		}
		fclose(f);
	}
	return err;
}

void countOM(int *atomics, int atomics_size, int *O_appearances, int *M_appearances){
    for (int i = 0; i < atomics_size; i++){
        if (atomics[i]==atomic_O){
            *O_appearances=*O_appearances+1;
        }
        else {
            *M_appearances = *M_appearances + 1;
        }
    }
}

int countO(int *atomics, int degree){
    int O_appearances = 0;
    for (int i = 0; i < degree; i++)
    {
        if (atomics[i]==atomic_O){
            O_appearances=O_appearances+1;
        }
    }
    return O_appearances;
}

void calculateIndices(int init, int index, int max_bonds, int *a, int *b, int *c, int *d){
    
    if (init == pow(max_bonds + 1, 4)){
        index = index - pow(max_bonds + 1, 4) - 1;
    }
    else if (init == 2*pow(max_bonds + 1, 4)){
        index = index - 2*pow(max_bonds + 1, 4) - 1;
    }
    
    *d = index % (max_bonds+1);
    index = index/(max_bonds+1);
    *c = index % (max_bonds+1);
    index = index/(max_bonds+1);
    *b = index % (max_bonds+1);
    index = index/(max_bonds+1);
    *a = index % (max_bonds+1);
    index = index/(max_bonds+1);
}

int generateNanofingerprint (char nano_file[100], int max_bons, float *section1, int *section2, int *section3, int *section4, char verbose[4]){

    FILE *f;
    int err = 0, i = 0, pos = 1;
    char filename_out[100];
    strcpy(filename_out,nano_file);
    strcat(filename_out, verbose);
    strcat(filename_out, ".txt");

    f = fopen(filename_out, "w");

    if (f==NULL)
    {
		err = -1;
	}
	else
    {
        
        // Section 1

        if (strcmp(verbose,"NV")!=0){
            fprintf(f,"Shell: %d\n", (int)section1[i++]);
            fprintf(f,"MaxBonds: %d\n", (int)section1[i++]);
            fprintf(f,"Size: %f\n", section1[i++]);
            fprintf(f,"Atomic: %d\n", (int)section1[i++]);
            fprintf(f,"O: %d\n", (int)section1[i++]);
            fprintf(f,"M: %d\n", (int)section1[i++]);
        }
        else{
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%f\n", section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
            fprintf(f,"%d\n", (int)section1[i++]);
        }

        // Section 2
        char at[2] = {'O', 'M'};
        pos = i + 1;
        i = 0;
        for (int a = 0; a < 2; a++)
        {
            for (int j = 0; j < max_bons; j++){
                if ((strcmp(verbose,"NV")!=0) && (strcmp(verbose,"VZ")==0 || section2[i] != 0)){
                    fprintf(f, "%d-> %c[%d]: %d\n", pos,at[a], j+1, section2[i]);  
                }
                else if (strcmp(verbose,"NV")==0){
                    fprintf(f, "%d\n", section2[i]);  
                }
                i++;
                pos++;
            }
        }

        // Section 3
        i = 0;
        for (int a = 0; a < 2; a++)
        {
            for (int j = 0; j <= max_bons; j++)
            {
                for (int k = 0; k <= max_bons; k++)
                {
                    if ((strcmp(verbose,"NV")!=0) && (strcmp(verbose,"VZ")==0 || section3[i] != 0)){
                        fprintf(f, "%d-> %c[%d,%d]: %d\n", pos,at[a], j, k, section3[i]);
                    }
                    else if (strcmp(verbose,"NV")==0){
                        fprintf(f, "%d\n", section3[i]);  
                    }
                    i++;
                    pos++;
                }
            }
        }
        
        // Section 4
        int a, b, c, d, init = 0;
        for (int el = 0; el <= 2; el++)
        {
            for (i = init; i < (el+1) * pow(max_bons + 1, 4); i++)
            {
                 if ((strcmp(verbose,"NV")!=0) && (strcmp(verbose,"VZ")==0 || section4[i] != 0)){
                    calculateIndices(init,i, max_bons, &a, &b, &c, &d);
                    if (el!=2){
                        fprintf(f, "%d-> %c[%d,%d]_%c[%d,%d]: %d\n", pos, at[el],a, b, at[el],c, d, section4[i]);
                    }
                    else{
                        fprintf(f, "%d-> %c[%d,%d]_%c[%d,%d]: %d\n", pos, at[0],a, b, at[1],c, d, section4[i]);
                    }
                }
                else if (strcmp(verbose,"NV")==0){
                    fprintf(f, "%d\n", section4[i]);  
                }

                pos++;
			}

            init = (el+1) * pow(max_bons + 1, 4);
        }

        fclose(f);
    }

    return err;
}

void getTime(struct timespec start, struct timespec end, double *execution_time,int *hours,int *min, int *sec, int *ms){

	clock_gettime(CLOCK_MONOTONIC, &end);
	*execution_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

	*hours = (int)*execution_time / 3600;
	*min = ((int)*execution_time % 3600) / 60;
	*sec = ((int)*execution_time % 3600) % 60;
	*ms = (int)((*execution_time - (int)*execution_time) * 1000);

}

void writecsv(char file_name[100], char graph[100], int value, double time){
    
    FILE *f;
    f = fopen(file_name, "a");

    fprintf(f,"%s,%d,%f\n",graph,value,time);
	fclose(f);
}

/*******************************************************************************
	Graph functions
********************************************************************************/

// Create a node
struct node* createNode(int v) {
  struct node* newNode = malloc(sizeof(struct node));
  newNode->vertex = v;
  newNode->next = NULL;
  return newNode;
}

// Create a graph
struct Graph* createGraph(int vertices) {
  struct Graph* graph = malloc(sizeof(struct Graph));
  graph->atomic_numbers = (int*)malloc(vertices*sizeof(int));
  graph->degree = (int*)malloc(vertices*sizeof(int));
  graph->shell = (int*)malloc(vertices*sizeof(int));
  graph->numVertices = vertices;
  graph->adjLists = malloc(vertices * sizeof(struct node*));

  for (int i = 0; i < vertices; i++){
    graph->adjLists[i] = NULL;
    graph->atomic_numbers[i] = 0;
    graph->degree[i] = 0;
	graph->shell[i] = 0;
  }

  return graph;
}

// Add edges to the graph from source (s) to destination (d)
void addEdge(struct Graph* graph, int node_s, int node_d) {
	
	// Add edge from s to d
	struct node* newNode = createNode(node_d);
	newNode->next = graph->adjLists[node_s];
	graph->adjLists[node_s] = newNode;
	graph->degree[node_s]++;
  
	
	struct node* newNode2 = createNode(node_s);
	newNode2->next = graph->adjLists[node_d];
	graph->adjLists[node_d] = newNode2;
	graph->degree[node_d]++;  

}

void addAtomic(struct Graph* graph, int node, int atomic){
  graph->atomic_numbers[node] = atomic;
}

void setShell(struct Graph* graph, int node){
  graph->shell[node] = 1;
}

int isShell(struct Graph* graph, int node){
  return graph->shell[node];
}

// Print the graph
void printGraph(struct Graph* graph) {
  int v;
  for (v = 0; v < graph->numVertices; v++) {
    struct node *temp = graph->adjLists[v];
    printf("\nVertex %d (at=%d, deg=%d): ", v,graph->atomic_numbers[v], graph->degree[v]);
    while (temp) {
      printf("-> %d ", temp->vertex);
      temp = temp->next;
    }
  }
}

int numVertices(struct Graph* graph){
  return graph->numVertices;
}

int degreeOfNode(struct Graph* graph, int node){
  return graph->degree[node];
}

int atomicOfNode(struct Graph* graph, int node){
  return graph->atomic_numbers[node];
}

int *getAtomics(struct Graph* graph){
  return graph->atomic_numbers;
}

int *getSurroundingNodesAtomic(struct Graph* graph, int node){
  struct node *temp = graph->adjLists[node];
  int i = 0;
  int *atomics = (int*)malloc(degreeOfNode(graph,node)*sizeof(int));
  while (temp)
  {
    atomics[i++] = atomicOfNode(graph,temp->vertex);
    temp = temp->next;
  }
  return atomics;
}

int *getSurroundingNodes(struct Graph* graph, int node){
  struct node *temp = graph->adjLists[node];
  int i = 0;
  int *nodes = (int*)malloc(degreeOfNode(graph,node)*sizeof(int));
  while (temp)
  {
    nodes[i++] = temp->vertex;
    temp = temp->next;
  }
  return nodes;
}

int xyzToGraph(char entry[100], int *atomic, struct Graph* graph, double size, double thickness)
{
	FILE *file_entry;

	int numatomic,rows,k,err=0;
	char element[2];
	float f1,f2,f3,dist_atom,distance; 
	bool sortir=false;

	float **table;
	int *listElements;
	
	file_entry=fopen(entry,"r");
	if (file_entry==NULL)
	{	
		err=-1;
	}
	else
	{
		fscanf(file_entry,"%d\n",&rows);
		table=(float **)malloc(rows*sizeof(float*));
		if (table==NULL)
		{
			err=-4;
		}
		else
		{
			listElements=(int *)malloc(rows*sizeof(int));
			if (listElements==NULL)
			{	
				err=-4;
			}
			else
			{
				fscanf(file_entry,"%*[^\n]");
				int found = false;
				for (int i = 0; !feof(file_entry) && !sortir; i++)
				{
					table[i]=(float*)malloc(3*sizeof(float));

					fscanf(file_entry,"%2s",element);
					numatomic=toAtomic(element);
					if (numatomic != atomic_O && !found){
						*atomic = numatomic;
						found = true;
					}
					if (numatomic==-1) {
						sortir=true;
					}
					else
					{
						listElements[i]=numatomic;
						addAtomic(graph, i, numatomic);
						fscanf(file_entry,"%f%f%f\n",&f1,&f2,&f3);
						if (calculateDistance(f1,f2,f3,0,0,0)>size/2-thickness){
							setShell(graph, i);
						}
						table[i][0]=f1;
						table[i][1]=f2;
						table[i][2]=f3;
					}
				}
				if (sortir)
				{
					err=-2;
				}
				else
				{
					for (int i=0;i<rows;i++)
					{
						for (int j=i+1;j<rows;j++)
						{							
							distance=calculateDistance(table[i][0],table[i][1],table[i][2],table[j][0],table[j][1],table[j][2]);
							dist_atom=distAtom(listElements[i],listElements[j]);
							if(distance<dist_atom)
							{
								addEdge(graph, i, j);
							}	
						}
					}
					fclose(file_entry);
				}
				free(listElements);	
			}					
			free(table);
		}
	}

	return err;

}

/*******************************************************************************
	Local Structure functions
********************************************************************************/

// Create a Local Structure
struct localStructure* createLocalStructure(int atomic, int O_connections, int M_connections) {
  struct localStructure* localStructure = malloc(sizeof(struct localStructure));
  localStructure->atomic = atomic;
  localStructure->O_connections = O_connections;
  localStructure->M_connections = M_connections;
  return localStructure;
}

// Create a Local Structuure List
struct localStructureList* createLocalStructureList(int maxElements) {

  struct localStructureList* localStructureList = malloc(sizeof(struct localStructureList));
  localStructureList->numLocalStructures = 0;
  localStructureList->node = (int*)malloc(maxElements*sizeof(int));
  localStructureList->list = malloc(maxElements * sizeof(struct localStructure *));
  
  for (int i = 0; i < maxElements; i++){
    localStructureList->node[i] = 0;
    localStructureList->list[i] = NULL;
  }
  
  return localStructureList;

}

struct localStructure* getLocalStructure (struct localStructureList* localStructureList, int pos){
  return localStructureList->list[pos];
}

void addLocalStructure(struct localStructureList* localStructureList, struct localStructure *localStructure, int n) {

  struct localStructure *newLocalStructure = malloc(sizeof(struct localStructure));
  memcpy(newLocalStructure, localStructure, sizeof(struct localStructure));

  localStructureList->list[localStructureList->numLocalStructures] = newLocalStructure;
  localStructureList->node[localStructureList->numLocalStructures] = n;
  localStructureList->numLocalStructures++;

}

int getNumLocalStructures (struct localStructureList* localStructureList){
  return localStructureList->numLocalStructures;
}

int getNodeAtPosition(struct localStructureList* localStructureList, int position){
  return localStructureList->node[position];
}

int getAtomic(struct localStructure* localStructure){
  return localStructure->atomic;
}

int getO_connections(struct localStructure* localStructure){
  return localStructure->O_connections;
}

int getM_connections(struct localStructure* localStructure){
  return localStructure->M_connections;
}

int reverseIndices(int index, int max_bonds){
	int last_digit = index % (max_bonds+1);
    int second_last_digit = (index / (max_bonds+1)) % (max_bonds+1);
    index = index / pow(max_bonds+1,2);
    index = last_digit * pow(max_bonds+1,2) + second_last_digit * pow(max_bonds+1,3) + index;
	return index;
}

bool hasToReverse(struct localStructure *localStructure_1, struct localStructure *localStructure_2){

	bool reverse = false;
	if (localStructure_2->O_connections > localStructure_1->O_connections)
	{
		reverse = true;
	}
	if (localStructure_2->O_connections == localStructure_1->O_connections && localStructure_2->M_connections > localStructure_1->M_connections){
		reverse = true;
	}

	return reverse;
}

void addElement(struct localStructureList* localStructureList, int* section4, int max_bonds, int pos_1, int pos_2){
  
  struct localStructure *localStructure_1 = malloc(sizeof(struct localStructure));
  memcpy(localStructure_1, localStructureList->list[pos_1], sizeof(struct localStructure));

  struct localStructure *localStructure_2 = malloc(sizeof(struct localStructure));
  memcpy(localStructure_2, localStructureList->list[pos_2], sizeof(struct localStructure));

  int index = localStructure_1->M_connections + pow(max_bonds+1,1) * localStructure_1->O_connections + pow(max_bonds+1,2) * localStructure_2->M_connections + pow(max_bonds+1,3) * localStructure_2->O_connections;
  
  if (getAtomic(localStructure_1)== atomic_O && getAtomic(localStructure_2)== atomic_O){
	if (hasToReverse(localStructure_1,localStructure_2)){
		index = reverseIndices(index, max_bonds);
	}
  }
  else if (getAtomic(localStructure_1)!= atomic_O && getAtomic(localStructure_2)!= atomic_O){
	if (hasToReverse(localStructure_1,localStructure_2)){
		index = reverseIndices(index, max_bonds);
	}
	index = index + pow(max_bonds+1, 4) + 1;
  } else if (localStructure_1->atomic != atomic_O){
	index = index + 2*pow(max_bonds+1, 4) + 1;
  } else if (localStructure_2->atomic != atomic_O){
	index = reverseIndices(index, max_bonds);
    index = index + 2*pow(max_bonds+1, 4) + 1;
  }

  section4[index]++;

  free(localStructure_1);
  free(localStructure_2);
}