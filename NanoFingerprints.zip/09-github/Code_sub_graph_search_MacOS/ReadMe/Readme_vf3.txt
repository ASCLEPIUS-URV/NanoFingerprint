CRIDAR PROGRAMA
./vf3l -s subG.xyz G.xyz          
./vf3 -s subG.xyz G.xyz            

-s perquè surtin totes les respostes
podem afegir que l'output es porti a un fitxer de sortida amb: > out.txt