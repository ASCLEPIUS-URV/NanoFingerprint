#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "../Functions/toAtomic.c"
#include "../Functions/distAtom.c"
#include "../Functions/calculateDistance.c"

int xyzToGraph(char entry[100],char out[100], int *numatoms)
{
	FILE *file_entry;
	FILE *file_out;
	int numatomic,rows,edge,k,err=0;
	char element[2];
	float f1,f2,f3,dist_atom,distance; 
	bool sortir=false;

	float **table;
	int **subtable, *listElements;
	
	file_entry=fopen(entry,"r");
	file_out=fopen(out,"w");
	if (file_entry==NULL)
	{	
		err=-1;
	}
	else
	{
		if (file_out==NULL)
		{	
			err=-3;
		}
		else
		{
			fscanf(file_entry,"%d\n",&*numatoms);
			fprintf(file_out,"%d\n",*numatoms);
			rows=*numatoms;
			table=(float **)malloc(rows*sizeof(float*));
			if (table==NULL)
			{
				err=-4;
			}
			else
			{
				for (int i=0;i<rows;i++)
				{
					table[i]=(float*)malloc(3*sizeof(float));
				}
				if (table==NULL)
				{
					err=-4;
				}
				else
				{
					subtable=(int **)malloc(rows*sizeof(int*));
					if (subtable==NULL)
					{
						err=-4;
					}
					else
					{
						for (int i=0;i<rows;i++)
						{
							subtable[i]=(int*)malloc(2*sizeof(int));
						}
						if (subtable==NULL)
						{
							err=-4;
						}
						else
						{
							listElements=(int *)malloc(rows*sizeof(int));
							if (listElements==NULL)
							{	
								err=-4;
							}
							else
							{
								fscanf(file_entry,"%*[^\n]");
								for (int i=0;!feof(file_entry) && !sortir;i++)
								{
									fscanf(file_entry,"%2s",element);
									fprintf(file_out,"%d ",i);
									numatomic=toAtomic(element);
									if (numatomic==-1) {
										sortir=true;
									}
									else
									{
										listElements[i]=numatomic;
										fprintf(file_out,"%d\n",numatomic);
										fscanf(file_entry,"%f%f%f\n",&f1,&f2,&f3);
										table[i][0]=f1;
										table[i][1]=f2;
										table[i][2]=f3;
									}
								}
								if (sortir)
								{
									err=-2;
								}
								else
								{
									for (int i=0;i<rows;i++)
									{
										edge=0;
										k=0;
										for (int j=0;j<rows;j++)
										{
											if (i!=j)
											{
												distance=calculateDistance(table[i][0],table[i][1],table[i][2],table[j][0],table[j][1],table[j][2]);
												dist_atom=distAtom(listElements[i],listElements[j]);
												if(distance<dist_atom)
												{
													edge++;
													subtable[k][0]=i;
													subtable[k][1]=j;
													k++;
												}
											}
										}
										fprintf(file_out,"%d\n",edge);
										if (edge!=0)
										{
											for (int j=0;j<k;j++)
											{
												if (subtable[j][0] == i)
												{
													fprintf(file_out,"%d ",subtable[j][0]);
													fprintf(file_out,"%d\n",subtable[j][1]);
												}
											}
										}
									}
									fclose(file_entry);
									fclose(file_out);
								}
								free(listElements);	
							}
							free(subtable);
						}					
					}
					free(table);
				}
			}
		}
	}
	return err;
}
