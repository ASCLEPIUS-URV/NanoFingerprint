#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> 
#include "Functions/xyzToGraph.c"
#include "Functions/vf3Execution.c"
#include "Functions/newGraph.c"
#include "Functions/grafToThickness.c"
#include "Functions/countAppearanes.c"
#include "Functions/readNumAtomsGraph.c"
#include "Functions/generateSubgraph.c"

#define atomic_O 8

int main(int argc, char *argv[])
{

	// Inputs
	// argv[0] - program name
	// argv[1] - graph xyz file
	// argv[2] - output xyz file
	// argv[3] - thickness (angstroms)
	// argv[4] - atomic center atom of the local structure
	// argv[5] - bonds to oxygen atoms
	// argv[6] - bonds to metal atoms

	struct timespec start, end;
	clock_gettime(CLOCK_MONOTONIC, &start);

	char graph[100], subgraph[100], path_input_graph[100],path_input_subgraph[100];
	char path_input_files[100] = "../Structures_xyz/";
	char path_generated_files[100] = "../Generated_Files/";
	char path_vf3[100] = "../vf3/";
	char vf3_out[50] = "\0";
	char nano_file[100] = "\0";
	char graph_thickness[100] = "\0";
	char graph_thickness_txt[100] = "\0";
	char output_file[100] ="";

	int status = 0, err = 0, coincident_nodes, thickness, max_bons, numatoms_subgraph, numatoms_graph, atomic_M, num_appearances, i = 0, local_structure[3];

	double execution_time, dist_max, size;

	strcpy(path_input_graph,path_input_files);

	strcat(output_file, path_generated_files);
	strcat(output_file, argv[2]);

	strcpy(subgraph,path_generated_files);
	strcat(subgraph, "Subgraph.txt");

	strcat(vf3_out,path_generated_files);
	strcat(vf3_out,"vf3out.txt");

	strcat(nano_file,path_generated_files);

	strcpy(graph_thickness,path_generated_files);

	if (argc!=7)
	{
		err=-1;
	}
	else
	{

		thickness = atof(argv[3]);

		strcpy(graph,argv[1]);

		strcat(path_input_graph, graph); 

		strcat(graph_thickness, graph);
		strtok(graph_thickness,".");
		strcat(graph_thickness, "_thickness.xyz");

		strcpy(graph_thickness_txt,graph_thickness);
		strtok(graph_thickness_txt,".");
		strcat(graph_thickness_txt, ".txt");

		status=graphToThickness(path_input_graph, thickness, graph_thickness, &dist_max);

		if (status==0)
		{
			status = xyzToGraph(graph_thickness, graph_thickness_txt, &numatoms_graph, &atomic_M);

			if (status==0)
			{

				// local structure composed by atomic number of central element, bonds with Oxygen, bonds with Metal
				// 22 6 0
				local_structure[0] = atof(argv[4]);
				local_structure[1] = atof(argv[5]);
				local_structure[2] = atof(argv[6]);

				// Code to generate a subgraph
				status = generateSubgraph(subgraph, atomic_O, atomic_M, local_structure, &numatoms_subgraph);

				if (status==0)
				{						
					status=vf3Execution(graph_thickness_txt,subgraph,vf3_out,path_vf3);
					
					if (status==0)
					{
						status = countAppearances(vf3_out, numatoms_subgraph, &num_appearances);
						
						if (status == 0){
							printf("Number of appeareances of the local structure into the graph: %d\n", num_appearances);
							status = newGraph(vf3_out, graph_thickness, output_file, &coincident_nodes);
							if (status == 0){
								printf("Number of coincident nodes in both graphs: %d\n", coincident_nodes);
							}
							else if (status == -1){
								err = -2;
							}
							else if (status == -2){
								err = -7;
							}
							else{
								err = -5;
							}
						}
						else if (status == -1)
						{
							err=-2;
						}
						else{
							err = -7;
						}
					}
					else
					{
						err=-4;
					}
				}
				else
				{
					if (status==-1)
					{
						err=-2;
					}
					else
					{
						if (status==-2)
						{
							err=-7;
						}
					}
				}
			}
			else
			{
				if (status==-1)
				{
					err=-2;
				}
				else
				{
					if (status==-2)
					{
						err=-3;
					}
					else{
						err = -7;
					}
				}
			}
		}
		else
		{
			if (status==-1)
			{
				err=-2;
			}
			else
			{
				if (status==-2)
				{
					err=-5;
				}
				else
				{
					if (status == -4)
					{
						err = -7;
					}
					else{
						err=-6;
					}
				}
			}
		}
	}
	if (err != 0){
		printf("Error: %d\n",err);
	}
	
	clock_gettime(CLOCK_MONOTONIC, &end);
	execution_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
	printf("Execution time (seconds): %f\n", execution_time);

	return err;
}
