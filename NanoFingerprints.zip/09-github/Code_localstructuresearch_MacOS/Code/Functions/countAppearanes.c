#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cmpfunc.c"

int countAppearances(char vf3_out[100], int numatoms_subgraph, int *num_appearances) 
{
	FILE *f;
	int num,err=0, *values, **values_prev, i, count_final, rows = 100, k=0;
	char line[100];
    char *token, *rest, *value, *rest_value, *ptr;
    bool equal;

	f=fopen(vf3_out,"r");
	if (f==NULL)
	{	
		err=-1;
	}
	else
	{
        num=fgetc(f);
        while(num!='\n')
        {
            num=fgetc(f);
        }

        *num_appearances = 0;

        values=(int *)malloc(numatoms_subgraph*sizeof(int));

        if (values==NULL)
        {
            err=-4;
        }
        else{

            memset(values, 0, numatoms_subgraph*sizeof(int));

            values_prev = (int **)malloc(rows * sizeof(int*));

            if (values_prev==NULL)
            {
                err=-4;
            }
            else{

                bool null = false;
                k = 0;

                while (k<rows && !null){
                    values_prev[k] = (int *)malloc(numatoms_subgraph * sizeof(int));
                    if (values_prev[k]==NULL){
                        null = true;
                    }
                    else{
                        k++;
                    }
                }
                if (null){
                    err = -4;
                }
                else{

                    for (int k = 0; k<rows; k++){
                        memset(values_prev[k], -1, numatoms_subgraph * sizeof(int)); // initialize -1: impossible value to get in the graph
                    } 

                    while (fgets(line, sizeof(line), f))
                    {
                        i = 0;
                        rest = line;
                        count_final = 0;
                        ptr = line;

                        while((ptr = strchr(ptr, ' ')) != NULL) {
                            count_final++;
                            ptr++;
                        }

                        // Last line of file contains 2 spaces ' '
                        if (count_final != 2){

                            while ((token = strtok_r(rest,":",&rest)))
                            {
                                rest_value = token;
                                value = strtok_r(rest_value, ",", &rest_value);
                                values[i++] = atoi(value);
                            }

                            // Ordering in ascending order
                            qsort(values, numatoms_subgraph, sizeof(int), cmpfunc);

                            equal = false;
                            k = 0;

                            // Compare with the previous different values matrix
                            while (k < *num_appearances && !equal)
                            {
                                if (memcmp(values, values_prev[k], numatoms_subgraph*sizeof(int)) == 0){
                                    equal = true;
                                }
                                else{
                                    k++;
                                }
                            }
                            
                            // Adding values array to the matrix values_prev if non-equal and counting an appearance
                            if (!equal){
                                for (int j = 0; j < numatoms_subgraph; j++){
                                    values_prev[*num_appearances][j] = values[j];
                                }
                                *num_appearances = *num_appearances + 1;
                            }
                        }
                    }
                }

                
                free(values_prev);
            }
            free(values);
        }
          
        fclose(f);

    }

    return err;
}