#include <stdio.h>

int generateSubgraph(char out[100], int O_atomic, int M_atomic, int local_structure[3], int *numatoms){

    FILE *file_out;
    int err = 0;
    int O_bonds, M_bonds;
    int **a; // adjacency matrix
    int *bonds; 

    file_out=fopen(out,"w");

    if (file_out==NULL)
    {	
        err=-1;
    }
    else{

        O_bonds = local_structure[1];
        M_bonds = local_structure[2];
        *numatoms = O_bonds + M_bonds + 1;

        a=(int **)malloc(*numatoms*sizeof(int*));
        if (a==NULL)
        {
            err=-2;
        }
        else
        {
            for (int i=0;i<*numatoms;i++)
            {
                a[i]=(int*)malloc(*numatoms*sizeof(int));
            }
            if (a==NULL)
            {
                err=-2;
            }
            else
            {
                for (int i=0;i<*numatoms;i++){
                    memset(a[i], 0, *numatoms*sizeof(int));
                }
                
                // central element bonds
                for (int j = 1; j < *numatoms; j++){
                    a[0][j] = 1;
                }

                // Bonds from central to other elements
                for (int i = 1; i < *numatoms; i++){
                    a[i][0] = 1;
                }

                bonds=(int*)malloc(*numatoms*sizeof(int));

                if (bonds==NULL)
                {
                    err=-2;
                }
                else{

                    memset(bonds, 0, *numatoms*sizeof(int));

                    for (int i = 0; i < *numatoms; i++){
                        for (int j = 0; j < *numatoms; j++)
                        {
                            if (a[i][j]==1){
                                bonds[i]++;
                            }
                        }
                    }

                    fprintf(file_out, "%d\n", *numatoms);
                    fprintf(file_out,"%d %d\n",0,local_structure[0]);

                    for (int i = 1; i <= O_bonds; i++){
                        fprintf(file_out,"%d %d\n",i,O_atomic);
                    }
                    for (int i = O_bonds + 1; i <= O_bonds+M_bonds; i++){
                        fprintf(file_out,"%d %d\n",i,M_atomic);
                    }

                    for (int i = 0; i < *numatoms; i++){
                        fprintf(file_out,"%d\n",bonds[i]);
                        for (int j = 0; j < *numatoms; j++){
                            if (a[i][j]==1){
                                fprintf(file_out,"%d %d\n",i, j);
                            }
                        }
                    }
                    free(bonds);
                }
                free(a);
            }
        }
  
    }

    fclose(file_out);

    return err;
}