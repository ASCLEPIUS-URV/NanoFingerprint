#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int vf3Execution(char graph[100], char subgraph[100], char file[50], char path_vf3[100])
{
	char string[150]="";
	int status;
	
	strcat(string,path_vf3);
	strcat(string,"./vf3l ");
	strcat(string, " -s ");
	strcat(string,subgraph);
	strcat(string," ./");
	strcat(string, graph);
	strcat(string, " > ");
	strcat(string, file);
	status=system(string);
	return status;
}	
