int readNumAtomsGraph(char entry[100], int *numatoms)
{
	FILE *file_entry;
	int err=0;
	
	file_entry=fopen(entry,"r");
    
	if (file_entry==NULL)
	{	
		err=-1;
	}
	else
	{
        fscanf(file_entry,"%d\n",&*numatoms);
    }

    return err;
}