#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int newGraph(char filename_out[100], char filename_graph[100], char converted[100], int *coincident_nodes) 
{
	FILE *f,*g,*final;
	int num,numatoms,qty=0,err=0;
	char sep,text[50],line[150];
	bool empty=true,surt=false;

	int *list;

	f=fopen(filename_out,"r");
	g=fopen(filename_graph,"r");
	final=fopen(converted,"w");
	if (f==NULL)
	{	
		err=-1;
	}
	else
	{
		if (g==NULL)
		{	
			err=-1;
		}
		else
		{
			if (final==NULL)
			{
				err=-3;
			}
			else
			{
				fscanf(g,"%d\n",&numatoms);
				num=fgetc(f);
				while(num!='\n')
				{
					num=fgetc(f);
				}
				list=(int *)malloc(numatoms*sizeof(int));
				if (list==NULL)
				{
					err=-2;
				}
				else
				{
					memset(list, 0, numatoms*sizeof(int));	
					while(!surt)
					{
						fscanf(f,"%d",&num);
						fscanf(f,"%c",&sep);
						if (sep==',')
						{
							if (list[num]==0)
							{
								list[num]=1;
								empty=false;
								qty++;
							}
						}
						if (sep==' ')
						{
							surt=true;
						}
					}
					fprintf(final,"%d\n",qty);
					*coincident_nodes=qty;
					fgets(text,50,g);
					text[strlen(text)-2]='\0';
					strcat(text,"_new");
					fprintf(final,"%s\n",text);
					if(!empty)
					{
						for (int i=0;i<numatoms;i++)
						{
							if (list[i]==1)
							{
								fgets(line,150,g);
								fprintf(final,"%s",line);
							}
							else
							{
								fgets(line,150,g);
							}
						}
					}
				}
				fclose(final);
			}
			fclose(g);
		}
		fclose(f);
	}	
	return err;
}	
