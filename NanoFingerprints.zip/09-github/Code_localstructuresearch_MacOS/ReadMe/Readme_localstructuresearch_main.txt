CODI

Dins la carpeta 'Code':

El main és el programa localstructuresearch_main.c

Les funcions utilizades estan a la carpeta 'Functions'

COMPILAR I CREAR EXECUTABLE

Primer, anar a la carpeta 'Code', utilitzant la instrucció 'cd'.

Un cop allà, fer:

gcc localstructuresearch_main.c -o localstructuresearch_main

En aquest cas, hem anomenat el programa 'localstructuresearch_main', però el podem anomenar com vulguem.

Es generarà arxiu executable a la carpeta Code.

Alternativament, es pot crear una carpeta bin i generar l'executable allà.

CRIDAR PROGRAMA

Anar a la carpeta Code, utilitzant la instrucció 'cd'.

Un cop allà, fer:

./localstructuresearch_main Graph.xyz SubGraph.xyz out.xyz 10

Paràmetres:
1. Graph (xyz).
2. Subgraph (en xyz o VF format -format graph-).
3. Nom del fitxer de sortida (xyz).
4. Thickness (angstroms).             

ALTRES

L'output xyz generat anirà a parar a la carpeta 'Generated_Files'.

Les estructures XYZ s'han de col·locar a la carpeta 'Structures_xyz', així com els fitxers intermedis generats durant l'execució. En cas de no voler-se, es pot editar el codi perquè elimini aquests fitxers intermedis amb la instrucció remove(path+nom fitxer).

VF3

Per generar l'executable vf3, necessari per l'execució del programa localstructuresearch_main, cal anar a:

https://github.com/MiviaLab/vf3lib

I descarregar-se o clonar el projecte.

Llavors, des de la carpeta principal ('vf3lib-master'), on hi ha el main ('main.cpp'), executar la següent instrucció al Terminal:

make conversion

Els executables es situaran a la carpeta 'bin'. 

Llavors, cal moure aquests executables a la carpeta del nostre projecte anomenada 'vf3'.