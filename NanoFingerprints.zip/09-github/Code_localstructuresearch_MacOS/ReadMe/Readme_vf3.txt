CRIDAR PROGRAMA
./vf3l -s subG.txt G.txt
./vf3 -s subG.txt G.txt            

-s perquè surtin totes les respostes
podem afegir que l'output es porti a un fitxer de sortida amb: > out.txt